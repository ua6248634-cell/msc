#!/usr/bin/env python3
"""
Shaurya OS Builder - Master Build Script
Builds custom Kali Linux-based penetration testing distribution
Features: XFCE Desktop, Arabic/English RTL, 1000+ Python tools, Fast mirrors
"""

import os
import sys
import json
import subprocess
import shutil
import argparse
from datetime import datetime
from pathlib import Path

class ShauryaBuilder:
    def __init__(self, config_dir=".", output_dir="./output"):
        self.config_dir = Path(config_dir)
        self.output_dir = Path(output_dir)
        self.build_dir = Path("/tmp/shaurya-build")
        self.log_file = self.output_dir / "build.log"

        self.variant = "shaurya"
        self.arch = "amd64"
        self.dist = "kali-rolling"
        self.version = "1.0.0"

        # Ensure directories exist
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def log(self, message, level="INFO"):
        """Log message to console and file"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}] [{level}] {message}"
        print(log_entry)

        with open(self.log_file, 'a') as f:
            f.write(log_entry + "\n")

    def run_command(self, cmd, cwd=None, timeout=300):
        """Execute shell command with logging"""
        self.log(f"Executing: {cmd}")
        try:
            result = subprocess.run(
                cmd, shell=True, cwd=cwd, timeout=timeout,
                capture_output=True, text=True
            )
            if result.returncode != 0:
                self.log(f"Command failed: {result.stderr}", "ERROR")
                return False, result.stderr
            return True, result.stdout
        except subprocess.TimeoutExpired:
            self.log("Command timed out", "ERROR")
            return False, "Timeout"
        except Exception as e:
            self.log(f"Exception: {str(e)}", "ERROR")
            return False, str(e)

    def prepare_build_environment(self):
        """Install required build dependencies"""
        self.log("Preparing build environment...")

        deps = [
            "git", "live-build", "simple-cdd", "cdebootstrap",
            "curl", "devscripts", "debootstrap", "squashfs-tools",
            "xorriso", "isolinux", "syslinux-efi", "grub-pc-bin",
            "grub-efi-amd64-bin", "mtools", "dosfstools", "parted"
        ]

        success, _ = self.run_command(f"apt-get update && apt-get install -y {' '.join(deps)}")
        if not success:
            self.log("Failed to install build dependencies", "ERROR")
            return False

        # Clone Kali build scripts
        if not self.build_dir.exists():
            success, _ = self.run_command(
                "git clone https://gitlab.com/kalilinux/build-scripts/live-build-config.git",
                cwd="/tmp"
            )
            if success:
                shutil.move("/tmp/live-build-config", self.build_dir)

        return True

    def setup_fast_mirror(self):
        """Configure fastest APT mirror"""
        self.log("Configuring fast mirror...")
        mirror_script = self.config_dir / "config/apt/mirror-config.py"
        if mirror_script.exists():
            success, _ = self.run_command(f"python3 {mirror_script}")
            return success
        return True

    def configure_packages(self):
        """Setup package lists for Shaurya OS"""
        self.log("Configuring package lists...")

        pkg_dir = self.build_dir / f"kali-config/variant-{self.variant}/package-lists"
        pkg_dir.mkdir(parents=True, exist_ok=True)

        # Main package list
        packages = """
# Shaurya OS Core Packages
kali-linux-default
kali-tools-top10
kali-linux-headless
kali-tools-web
kali-tools-wireless
kali-tools-reverse-engineering
kali-tools-forensics
kali-tools-post-exploitation

# XFCE Desktop
kali-desktop-xfce
xfce4
xfce4-goodies
xfce4-power-manager
xfce4-terminal
xfce4-panel
xfce4-whiskermenu-plugin
lightdm
lightdm-gtk-greeter

# Arabic/International Support
locales-all
fonts-arabeyes
fonts-noto-arabic
fonts-noto-ui-core
ibus
ibus-anthy
ibus-m17n
libreoffice-l10n-ar
firefox-esr-l10n-ar

# Python Development
python3
python3-pip
python3-venv
python3-dev
python3-full
ipython3
jupyter-notebook

# Reverse Engineering & Analysis
radare2
radare2-cutter
gdb
gdb-multiarch
qemu-user-static
binwalk
yara
volatility3

# Drivers & Hardware Support
firmware-linux
firmware-linux-nonfree
firmware-misc-nonfree
firmware-realtek
firmware-atheros
firmware-iwlwifi
nvidia-driver
amd64-microcode
intel-microcode

# Network & Wireless
wireless-tools
wpasupplicant
aircrack-ng
crunch
dnsmasq
hostapd
iw
kismet
macchanger
reaver
wifi-honey

# Utilities
htop
btop
neofetch
tree
ranger
fzf
ripgrep
fd-find
bat
eza
zsh
fish
"""

        with open(pkg_dir / "kali.list.chroot", 'w') as f:
            f.write(packages)

        return True

    def create_hooks(self):
        """Create chroot hooks for customization"""
        self.log("Creating build hooks...")

        hooks_dir = self.build_dir / "kali-config/common/hooks"
        hooks_dir.mkdir(parents=True, exist_ok=True)

        # Hook 1: Shaurya Setup
        hook1 = """#!/bin/bash
set -e

echo "[+] Shaurya OS Setup Hook"

# Configure fast mirror
python3 /config/apt/mirror-config.py || true

# Install mass Python tools
cd /tools-installer/scripts
python3 mass-installer.py --config /tools-installer/categories/tools-manifest.json || true

# Configure XFCE Arabic/RTL
bash /config/xfce/arabic-rtl.sh || true

echo "[+] Shaurya OS setup complete"
"""

        with open(hooks_dir / "01-shaurya-setup.chroot", 'w') as f:
            f.write(hook1)
        os.chmod(hooks_dir / "01-shaurya-setup.chroot", 0o755)

        return True

    def copy_config_files(self):
        """Copy configuration files to build directory"""
        self.log("Copying configuration files...")

        # Copy tools installer
        tools_src = self.config_dir / "tools-installer"
        tools_dst = self.build_dir / "tools-installer"
        if tools_src.exists():
            shutil.copytree(tools_src, tools_dst, dirs_exist_ok=True)

        # Copy config files
        config_src = self.config_dir / "config"
        config_dst = self.build_dir / "config"
        if config_src.exists():
            shutil.copytree(config_src, config_dst, dirs_exist_ok=True)

        return True

    def build_iso(self):
        """Build the ISO image"""
        self.log("Starting ISO build process...")

        # Clean previous builds
        self.run_command("lb clean --purge", cwd=self.build_dir)

        # Build configuration
        build_cmd = f"""./build.sh \\
            --variant {self.variant} \\
            --arch {self.arch} \\
            --distribution {self.dist} \\
            --verbose \\
            --version "{self.version}"
        """

        success, output = self.run_command(build_cmd, cwd=self.build_dir, timeout=7200)

        if success:
            # Copy output
            iso_dir = self.build_dir / "images"
            if iso_dir.exists():
                for iso in iso_dir.glob("*.iso"):
                    shutil.copy2(iso, self.output_dir)
                    self.log(f"ISO created: {iso.name}")
                return True

        self.log("ISO build failed", "ERROR")
        return False

    def create_sha256sums(self):
        """Generate checksums for ISO files"""
        self.log("Generating checksums...")

        for iso in self.output_dir.glob("*.iso"):
            success, _ = self.run_command(f"sha256sum {iso.name} > {iso.name}.sha256sum", 
                                          cwd=self.output_dir)
        return True

    def build(self, skip_deps=False):
        """Full build process"""
        self.log("="*60)
        self.log("SHAURYA OS BUILD STARTED")
        self.log(f"Version: {self.version}")
        self.log(f"Architecture: {self.arch}")
        self.log(f"Variant: {self.variant}")
        self.log("="*60)

        steps = [
            ("Environment", self.prepare_build_environment, not skip_deps),
            ("Fast Mirror", self.setup_fast_mirror, True),
            ("Packages", self.configure_packages, True),
            ("Hooks", self.create_hooks, True),
            ("Config Files", self.copy_config_files, True),
            ("ISO Build", self.build_iso, True),
            ("Checksums", self.create_sha256sums, True)
        ]

        for step_name, step_func, should_run in steps:
            if should_run:
                self.log(f"\n[STEP] {step_name}...")
                if not step_func():
                    self.log(f"Build failed at step: {step_name}", "ERROR")
                    return False

        self.log("\n" + "="*60)
        self.log("SHAURYA OS BUILD COMPLETED SUCCESSFULLY")
        self.log(f"Output directory: {self.output_dir}")
        self.log("="*60)
        return True

def main():
    parser = argparse.ArgumentParser(description="Shaurya OS Builder")
    parser.add_argument("--config", "-c", default=".", help="Configuration directory")
    parser.add_argument("--output", "-o", default="./output", help="Output directory")
    parser.add_argument("--skip-deps", action="store_true", help="Skip dependency installation")
    parser.add_argument("--version", "-v", default="1.0.0", help="OS Version")

    args = parser.parse_args()

    builder = ShauryaBuilder(config_dir=args.config, output_dir=args.output)
    builder.version = args.version

    success = builder.build(skip_deps=args.skip_deps)
    sys.exit(0 if success else 1)

if __name__ == "__main__":
    main()
