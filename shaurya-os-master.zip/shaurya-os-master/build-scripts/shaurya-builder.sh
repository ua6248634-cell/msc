#!/bin/bash
# Shaurya OS Build Wrapper
# Simple bash interface to Python build script

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD_SCRIPT="${SCRIPT_DIR}/build.py"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Functions
print_banner() {
    echo -e "${BLUE}"
    echo "╔══════════════════════════════════════════════════════════════╗"
    echo "║                    SHAURYA OS BUILDER                        ║"
    echo "║          Advanced Penetration Testing Platform               ║"
    echo "╚══════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

print_usage() {
    echo "Usage: $0 [OPTIONS]"
    echo ""
    echo "Options:"
    echo "  -v, --version VERSION    Set OS version (default: 1.0.0)"
    echo "  -a, --arch ARCH          Set architecture (default: amd64)"
    echo "  -o, --output DIR         Set output directory (default: ./output)"
    echo "  -s, --skip-deps          Skip dependency installation"
    echo "  -c, --clean             Clean build (purge cache)"
    echo "  -t, --test              Test ISO with QEMU after build"
    echo "  -h, --help              Show this help message"
    echo ""
    echo "Examples:"
    echo "  $0                      # Build with defaults"
    echo "  $0 -v 2.0.0             # Build version 2.0.0"
    echo "  $0 -c -v 1.5.0          # Clean build version 1.5.0"
    echo "  $0 -t                   # Build and test with QEMU"
}

# Default values
VERSION="1.0.0"
ARCH="amd64"
OUTPUT="./output"
SKIP_DEPS=false
CLEAN=false
TEST_ISO=false

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        -v|--version)
            VERSION="$2"
            shift 2
            ;;
        -a|--arch)
            ARCH="$2"
            shift 2
            ;;
        -o|--output)
            OUTPUT="$2"
            shift 2
            ;;
        -s|--skip-deps)
            SKIP_DEPS=true
            shift
            ;;
        -c|--clean)
            CLEAN=true
            shift
            ;;
        -t|--test)
            TEST_ISO=true
            shift
            ;;
        -h|--help)
            print_usage
            exit 0
            ;;
        *)
            echo -e "${RED}Unknown option: $1${NC}"
            print_usage
            exit 1
            ;;
    esac
done

print_banner

# Check if running as root
if [[ $EUID -ne 0 ]]; then
    echo -e "${RED}This script must be run as root (use sudo)${NC}"
    exit 1
fi

# Clean build if requested
if [[ "$CLEAN" == true ]]; then
    echo -e "${YELLOW}[+] Cleaning previous builds...${NC}"
    cd /tmp/live-build-config 2>/dev/null && lb clean --purge 2>/dev/null || true
    rm -rf /tmp/live-build-config
    rm -rf "$OUTPUT"
    echo -e "${GREEN}[✓] Clean complete${NC}"
fi

# Check Python build script exists
if [[ ! -f "$BUILD_SCRIPT" ]]; then
    echo -e "${RED}Error: Build script not found at $BUILD_SCRIPT${NC}"
    exit 1
fi

# Build command
BUILD_CMD="python3 "$BUILD_SCRIPT" --version $VERSION --arch $ARCH --output $OUTPUT"

if [[ "$SKIP_DEPS" == true ]]; then
    BUILD_CMD="$BUILD_CMD --skip-deps"
fi

echo -e "${BLUE}[+] Starting Shaurya OS build...${NC}"
echo -e "${BLUE}    Version: $VERSION${NC}"
echo -e "${BLUE}    Architecture: $ARCH${NC}"
echo -e "${BLUE}    Output: $OUTPUT${NC}"
echo ""

# Run build
eval $BUILD_CMD

BUILD_STATUS=$?

if [[ $BUILD_STATUS -eq 0 ]]; then
    echo ""
    echo -e "${GREEN}[✓] Build completed successfully!${NC}"

    # Show output files
    if [[ -d "$OUTPUT" ]]; then
        echo ""
        echo -e "${BLUE}[+] Output files:${NC}"
        ls -lh "$OUTPUT"/*.iso 2>/dev/null || echo "No ISO files found"
    fi

    # Test ISO if requested
    if [[ "$TEST_ISO" == true ]]; then
        ISO_FILE=$(ls -t "$OUTPUT"/*.iso 2>/dev/null | head -1)
        if [[ -f "$ISO_FILE" ]]; then
            echo ""
            echo -e "${YELLOW}[+] Testing ISO with QEMU...${NC}"
            echo "    Press Ctrl+A then X to exit QEMU"
            echo ""

            # Check if qemu is installed
            if ! command -v qemu-system-x86_64 &> /dev/null; then
                echo -e "${YELLOW}[!] QEMU not installed, installing...${NC}"
                apt-get update && apt-get install -y qemu-system-x86 ovmf
            fi

            # Run QEMU
            qemu-system-x86_64                 -enable-kvm                 -m 4096                 -cdrom "$ISO_FILE"                 -boot once=d                 -display gtk                 -vga std                 -net nic -net user                 2>/dev/null ||             qemu-system-x86_64                 -m 4096                 -cdrom "$ISO_FILE"                 -boot once=d                 -display gtk                 -vga std                 -net nic -net user
        else
            echo -e "${RED}[!] No ISO file found for testing${NC}"
        fi
    fi

    echo ""
    echo -e "${GREEN}══════════════════════════════════════════════════════════════${NC}"
    echo -e "${GREEN}  SHAURYA OS BUILD SUCCESSFUL${NC}"
    echo -e "${GREEN}══════════════════════════════════════════════════════════════${NC}"

else
    echo ""
    echo -e "${RED}[✗] Build failed with status code: $BUILD_STATUS${NC}"
    echo -e "${RED}Check build.log for details${NC}"
    exit 1
fi
