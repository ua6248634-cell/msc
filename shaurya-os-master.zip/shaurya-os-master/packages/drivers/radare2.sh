#!/bin/bash
# Shaurya OS - Radare2 Advanced Installation
# Builds latest radare2 from source with all plugins

set -e

echo "[+] Shaurya OS Radare2 Installer"

# Install dependencies
echo "[+] Installing build dependencies..."
apt-get update
apt-get install -y     git     build-essential     cmake     meson     ninja-build     pkg-config     libssl-dev     libffi-dev     libreadline-dev     libzip-dev     liblz4-dev     libxxhash-dev     libuv1-dev     libcapstone-dev     libmagic-dev     libgmp-dev     libpcre3-dev     libglib2.0-dev     libcairo2-dev     libgirepository1.0-dev     libjavascriptcoregtk-4.0-dev     libgtk-3-dev     libappindicator3-dev     libsoup2.4-dev     python3-dev     python3-pip     python3-setuptools     valac     swig     qtbase5-dev     qtchooser     qt5-qmake     qtbase5-dev-tools     libqt5svg5-dev     qttools5-dev     qttools5-dev-tools

# Clone radare2
echo "[+] Cloning radare2 repository..."
R2_DIR="/opt/radare2"
if [ -d "$R2_DIR" ]; then
    cd "$R2_DIR"
    git pull
else
    git clone --depth 1 https://github.com/radareorg/radare2.git "$R2_DIR"
    cd "$R2_DIR"
fi

# Build and install radare2
echo "[+] Building radare2..."
sys/install.sh

# Install radare2 plugins
echo "[+] Installing radare2 plugins..."

# r2ghidra (decompiler)
r2pm -ci r2ghidra || true

# r2dec (decompiler)
r2pm -ci r2dec || true

# r2frida (dynamic instrumentation)
r2pm -ci r2frida || true

# r2yara (YARA integration)
r2pm -ci r2yara || true

# r2poke (Poke integration)
r2pm -ci r2poke || true

# r2winedbg (Windows debugger)
r2pm -ci r2winedbg || true

# r2retdec (RetDec integration)
r2pm -ci retdec-r2plugin || true

# Install Cutter (GUI)
echo "[+] Installing Cutter (radare2 GUI)..."
CUTTER_VERSION="2.3.4"
wget -q "https://github.com/rizinorg/cutter/releases/download/v${CUTTER_VERSION}/Cutter-v${CUTTER_VERSION}-Linux-x86_64.AppImage"     -O /usr/local/bin/cutter
chmod +x /usr/local/bin/cutter

# Create radare2 configuration
echo "[+] Configuring radare2..."
mkdir -p /etc/skel/.config/radare2
mkdir -p /etc/skel/.local/share/radare2

# Default radare2rc
cat > /etc/skel/.radare2rc << 'EOF'
# Shaurya OS radare2 configuration

# Colors and theme
e scr.color=3
e scr.utf8=true
e scr.pager=less -R

# Analysis
ea
e anal.hasnext=true
e anal.depth=64
e anal.in=io.maps.x
e anal.autoname=true
e anal.types.constraint=true

# Display
e asm.pseudo=true
e asm.syntax=intel
e asm.bytes=true
e asm.flags=true
e asm.offset=true
e asm.lines=true
e asm.lines.ret=true
e asm.lines.call=true
e asm.lines.trace=true
e asm.lines.out=true
e asm.lines.right=true
e asm.lines.width=20
e asm.section=true
e asm.sub.names=true
e asm.sub.section=true
e asm.sub.jmp=true
e asm.sub.var=true
e asm.sub.varonly=true
e asm.bbline=true
e asm.comments=true
e asm.usercomments=true
e asm.leahints=true
e asm.fcncalls=true
e asm.fcnlines=true

# Search
e search.in=io.maps.x
e search.align=4
e search.flags=true

# ESIL
e esil.verbose=false

# Debugger
e dbg.follow.child=true
e dbg.btalgo=analysis
e dbg.btsize=512

# UI
e scr.histsave=true
e scr.histfile=~/.cache/radare2/history
e scr.histfilter=true

# Plugins
e cfg.plugins=true

# Auto-load projects
e prj.auto=true
e prj.file=~/.local/share/radare2/projects

# Better graphs
e graph.offset=true
e graph.bytes=true
e graph.comments=true
e graph.cmtright=true

# Enable syntax highlighting
e scr.highlight.grep=true
EOF

# Install r2pipe for Python
echo "[+] Installing r2pipe Python bindings..."
pip3 install r2pipe

# Create wrapper scripts
cat > /usr/local/bin/r2-analysis << 'EOF'
#!/bin/bash
# Automated analysis wrapper for radare2
r2 -A "$@"
EOF
chmod +x /usr/local/bin/r2-analysis

cat > /usr/local/bin/r2-debug << 'EOF'
#!/bin/bash
# Debug wrapper for radare2
r2 -d "$@"
EOF
chmod +x /usr/local/bin/r2-debug

cat > /usr/local/bin/r2-decompile << 'EOF'
#!/bin/bash
# Decompile wrapper using r2ghidra
r2 -c "pdg" -q "$@"
EOF
chmod +x /usr/local/bin/r2-decompile

# Verify installation
echo "[+] Verifying installation..."
r2 -v
r2pm -l

# Create desktop entry for Cutter
cat > /usr/share/applications/cutter.desktop << 'EOF'
[Desktop Entry]
Name=Cutter
Comment=Reverse Engineering Platform powered by radare2
Exec=/usr/local/bin/cutter %F
Icon=utilities-terminal
Type=Application
Categories=Development;Debugger;Security;
MimeType=application/x-executable;application/x-sharedlib;
Terminal=false
EOF

echo "[✓] Radare2 installation complete"
echo "[✓] Plugins installed: r2ghidra, r2dec, r2frida, r2yara"
echo "[✓] Cutter GUI installed"
echo "[✓] Python bindings (r2pipe) installed"
echo "[✓] Configuration files created"
