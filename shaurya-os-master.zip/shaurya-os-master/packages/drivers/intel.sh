#!/bin/bash
# Shaurya OS - Intel Driver Installation Script
# Supports Intel integrated and Arc GPUs

set -e

echo "[+] Shaurya OS Intel Driver Installer"

# Detect Intel GPU
if ! lspci | grep -i intel | grep -i vga > /dev/null; then
    echo "[!] No Intel GPU detected"
    exit 0
fi

GPU_INFO=$(lspci | grep -i intel | grep -i vga | head -1)
echo "[+] Found: $GPU_INFO"

# Install Intel drivers
echo "[+] Installing Intel graphics drivers..."
apt-get update
apt-get install -y     intel-media-va-driver     intel-media-va-driver-non-free     i965-va-driver     i965-va-driver-shaders     va-driver-all     vdpau-driver-all     libvdpau-va-gl1     libva-drm2     libva-x11-2     libva-glx2     libva-wayland2     libvdpau1     vainfo     vdpauinfo     mesa-utils     mesa-va-drivers     mesa-vdpau-drivers     mesa-vulkan-drivers     vulkan-tools     libvulkan1     intel-gpu-tools

# Install Intel OpenCL runtime for hashcat
echo "[+] Installing Intel OpenCL support..."
apt-get install -y     intel-opencl-icd     ocl-icd-libopencl1     clinfo

# Intel Arc GPU support (Alchemist)
echo "[+] Checking for Intel Arc GPU..."
if lspci | grep -i "Arc\|Alchemist" > /dev/null; then
    echo "[+] Intel Arc GPU detected, installing latest Mesa..."
    apt-get install -y         libgl1-mesa-dri         libglx-mesa0         mesa-vulkan-drivers         libglapi-mesa         libgbm1
fi

# Configure VA-API
echo "[+] Configuring VA-API..."
cat > /etc/profile.d/intel-vaapi.sh << 'EOF'
export LIBVA_DRIVER_NAME=i965
export LIBVA_DRIVERS_PATH=/usr/lib/x86_64-linux-gnu/dri
EOF

# Verify installation
echo "[+] Verifying installation..."
vainfo || true
clinfo | grep -i intel || true
intel_gpu_top --help || true

echo "[✓] Intel driver installation complete"
