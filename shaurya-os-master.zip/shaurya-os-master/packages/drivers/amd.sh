#!/bin/bash
# Shaurya OS - AMD Driver Installation Script
# Supports Radeon and AMDGPU

set -e

echo "[+] Shaurya OS AMD Driver Installer"

# Detect AMD GPU
if ! lspci | grep -i amd | grep -i vga > /dev/null && ! lspci | grep -i ati > /dev/null; then
    echo "[!] No AMD GPU detected"
    exit 0
fi

GPU_INFO=$(lspci | grep -iE "amd|ati" | grep -i vga | head -1)
echo "[+] Found: $GPU_INFO"

# Install AMD drivers
echo "[+] Installing AMD graphics drivers..."
apt-get update
apt-get install -y     firmware-amd-graphics     libdrm-amdgpu1     libdrm-radeon1     xserver-xorg-video-amdgpu     xserver-xorg-video-ati     xserver-xorg-video-radeon     mesa-utils     mesa-va-drivers     mesa-vdpau-drivers     mesa-vulkan-drivers     vulkan-tools     libvulkan1     vainfo     vdpauinfo     radeontop     rocm-opencl-runtime     rocm-smi     hip-runtime-amd

# ROCm for machine learning and compute
echo "[+] Installing ROCm platform..."
apt-get install -y     rocm-dkms     rocm-dev     rocm-utils || true

# Configure OpenCL
echo "[+] Configuring OpenCL..."
cat > /etc/profile.d/amdgpu.sh << 'EOF'
export HSA_OVERRIDE_GFX_VERSION=10.3.0
export ROCM_PATH=/opt/rocm
export PATH=$ROCM_PATH/bin:$PATH
export LD_LIBRARY_PATH=$ROCM_PATH/lib:$LD_LIBRARY_PATH
EOF

# Enable AMD GPU support for hashcat
echo "[+] Optimizing for hashcat..."
cat > /etc/udev/rules.d/50-amdgpu.rules << 'EOF'
KERNEL=="kfd", MODE="0666", TAG+="uaccess"
KERNEL=="renderD*", MODE="0666", TAG+="uaccess"
EOF

# Verify installation
echo "[+] Verifying installation..."
vainfo || true
rocminfo || true
radeontop -d - || true

echo "[✓] AMD driver installation complete"
