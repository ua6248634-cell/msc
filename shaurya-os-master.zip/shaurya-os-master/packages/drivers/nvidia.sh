#!/bin/bash
# Shaurya OS - NVIDIA Driver Installation Script
# Supports latest NVIDIA GPUs with CUDA support

set -e

echo "[+] Shaurya OS NVIDIA Driver Installer"
echo "[+] Detecting NVIDIA hardware..."

# Check for NVIDIA GPU
if ! lspci | grep -i nvidia > /dev/null; then
    echo "[!] No NVIDIA GPU detected"
    exit 0
fi

# Detect GPU model
GPU_MODEL=$(lspci | grep -i nvidia | head -1 | cut -d':' -f3)
echo "[+] Found: $GPU_MODEL"

# Install dependencies
echo "[+] Installing dependencies..."
apt-get update
apt-get install -y     linux-headers-$(uname -r)     build-essential     dkms     pkg-config     libglvnd-dev     libglvnd-core-dev     libglvnd0     libglx0     libglx-mesa0     libegl1     libgles2     firmware-misc-nonfree

# Install NVIDIA driver from Kali repos (recommended)
echo "[+] Installing NVIDIA driver..."
apt-get install -y     nvidia-driver     nvidia-cuda-toolkit     nvidia-cuda-dev     nvidia-cudnn     nvidia-settings     nvidia-xconfig     nvidia-persistenced     nvidia-smi     libnvidia-encode1     libnvidia-decode1     libnvidia-fbc1     libnvidia-ml1     libnvidia-ptxjitcompiler1     libnvidia-opticalflow1     libnvidia-glvkspirv1

# Alternative: Install from NVIDIA runfile (for latest drivers)
# Uncomment below to use NVIDIA's official driver
# NVIDIA_VERSION="550.54.14"
# wget https://us.download.nvidia.com/XFree86/Linux-x86_64/${NVIDIA_VERSION}/NVIDIA-Linux-x86_64-${NVIDIA_VERSION}.run
# chmod +x NVIDIA-Linux-x86_64-${NVIDIA_VERSION}.run
# ./NVIDIA-Linux-x86_64-${NVIDIA_VERSION}.run --silent --dkms

# Configure Xorg for NVIDIA
echo "[+] Configuring Xorg..."
nvidia-xconfig --allow-empty-initial-configuration     --use-display-device=None     --virtual=1920x1080     --enable-all-gpus     --separate-x-screens     --no-use-edid-freqs     --no-use-edid-dims     --no-xinerama     --no-composite || true

# Enable persistence mode for compute
echo "[+] Enabling persistence mode..."
cat > /etc/systemd/system/nvidia-persistenced.service << 'EOF'
[Unit]
Description=NVIDIA Persistence Daemon
Wants=syslog.target
After=syslog.target

[Service]
Type=forking
ExecStart=/usr/bin/nvidia-persistenced --verbose
ExecStopPost=/bin/rm -rf /var/run/nvidia-persistenced

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable nvidia-persistenced
systemctl start nvidia-persistenced

# Hashcat optimization for NVIDIA
echo "[+] Optimizing hashcat for NVIDIA..."
cat > /etc/profile.d/nvidia-hashcat.sh << 'EOF'
export CUDA_CACHE_DISABLE=0
export CUDA_CACHE_MAXSIZE=2147483647
export NVIDIA_COMPUTE_MODE=DEFAULT
EOF

# Verify installation
echo "[+] Verifying installation..."
nvidia-smi

# CUDA environment setup
echo "[+] Setting up CUDA environment..."
cat > /etc/profile.d/cuda.sh << 'EOF'
export PATH=/usr/local/cuda/bin:$PATH
export LD_LIBRARY_PATH=/usr/local/cuda/lib64:$LD_LIBRARY_PATH
EOF

echo "[✓] NVIDIA driver installation complete"
echo "[✓] CUDA toolkit installed"
echo "[✓] Persistence mode enabled"
echo "[✓] Hashcat optimized"
echo ""
echo "[!] Reboot required for full functionality"
