#!/usr/bin/env python3
# Shaurya OS - Mass Python Tools Installer
# Installs 1000+ GitHub tools with intelligent categorization

import os
import sys
import json
import subprocess
import multiprocessing
import argparse
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime

class ShauryaInstaller:
    def __init__(self, config_file="tools-manifest.json"):
        self.base_dir = "/opt/shaurya-tools"
        self.venv_base = "/opt/shaurya-venvs"
        self.log_file = "/var/log/shaurya-installer.log"
        self.config = self.load_config(config_file)
        self.stats = {
            "total": 0,
            "success": 0,
            "failed": 0,
            "skipped": 0,
            "apt": 0,
            "pip": 0,
            "git": 0
        }

    def load_config(self, config_file):
        with open(config_file, 'r') as f:
            return json.load(f)

    def log(self, message, level="INFO"):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}] [{level}] {message}"
        print(log_entry)
        with open(self.log_file, 'a') as f:
            f.write(log_entry + "\n")

    def run_command(self, cmd, cwd=None, timeout=300):
        try:
            result = subprocess.run(
                cmd, shell=True, cwd=cwd, timeout=timeout,
                capture_output=True, text=True
            )
            return result.returncode == 0, result.stdout, result.stderr
        except subprocess.TimeoutExpired:
            return False, "", "Command timed out"
        except Exception as e:
            return False, "", str(e)

    def install_apt(self, package):
        if not package:
            return True
        success, stdout, stderr = self.run_command(f"apt-get install -y {package}")
        if success:
            self.stats["apt"] += 1
        return success

    def install_pip(self, package, venv_name=None):
        if not package:
            return True

        if venv_name:
            venv_path = os.path.join(self.venv_base, venv_name)
            pip_cmd = f"{venv_path}/bin/pip install {package}"
        else:
            pip_cmd = f"pip3 install {package}"

        success, stdout, stderr = self.run_command(pip_cmd)
        if success:
            self.stats["pip"] += 1
        return success

    def clone_repo(self, repo_url, dest_dir):
        if os.path.exists(dest_dir):
            self.log(f"Directory exists, updating: {dest_dir}")
            success, _, _ = self.run_command("git pull", cwd=dest_dir)
            return success

        success, stdout, stderr = self.run_command(f"git clone --depth 1 {repo_url} {dest_dir}")
        if success:
            self.stats["git"] += 1
        return success

    def install_tool(self, tool_info):
        name = tool_info["name"]
        repo = tool_info.get("repo")
        pip_pkg = tool_info.get("pip")
        apt_pkg = tool_info.get("apt")
        category = tool_info.get("category", "misc")

        self.log(f"Installing {name} ({category})...")

        # Create category directory
        cat_dir = os.path.join(self.base_dir, category)
        os.makedirs(cat_dir, exist_ok=True)

        # Try APT first
        if apt_pkg:
            if self.install_apt(apt_pkg):
                self.log(f"✓ {name} installed via APT")
                return True

        # Try PIP
        if pip_pkg:
            venv_name = f"{category}-{name}"
            if self.install_pip(pip_pkg, venv_name):
                self.log(f"✓ {name} installed via PIP")
                return True

        # Clone from GitHub
        if repo:
            repo_url = f"https://github.com/{repo}.git"
            dest = os.path.join(cat_dir, name)
            if self.clone_repo(repo_url, dest):
                # Try to install requirements if exists
                req_file = os.path.join(dest, "requirements.txt")
                if os.path.exists(req_file):
                    self.run_command(f"pip3 install -r {req_file}", cwd=dest)
                self.log(f"✓ {name} cloned from GitHub")
                return True

        self.log(f"✗ Failed to install {name}", "ERROR")
        return False

    def install_category(self, category_name, max_workers=8):
        if category_name not in self.config["categories"]:
            self.log(f"Category not found: {category_name}", "ERROR")
            return

        tools = self.config["categories"][category_name]["tools"]
        self.log(f"Installing {len(tools)} tools from category: {category_name}")

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {executor.submit(self.install_tool, tool): tool for tool in tools}

            for future in as_completed(futures):
                tool = futures[future]
                try:
                    success = future.result()
                    self.stats["total"] += 1
                    if success:
                        self.stats["success"] += 1
                    else:
                        self.stats["failed"] += 1
                except Exception as e:
                    self.log(f"Exception installing {tool['name']}: {e}", "ERROR")
                    self.stats["failed"] += 1

    def install_all(self, max_workers=8):
        self.log("Starting mass installation of all Shaurya OS tools...")

        # Create base directories
        os.makedirs(self.base_dir, exist_ok=True)
        os.makedirs(self.venv_base, exist_ok=True)

        # Update package lists
        self.log("Updating package lists...")
        self.run_command("apt-get update")

        # Install categories
        categories = list(self.config["categories"].keys())
        for cat in categories:
            self.install_category(cat, max_workers)

        # Print summary
        self.print_summary()

    def print_summary(self):
        print("\n" + "="*60)
        print("SHAURYA OS - INSTALLATION SUMMARY")
        print("="*60)
        print(f"Total tools processed: {self.stats['total']}")
        print(f"Successfully installed: {self.stats['success']}")
        print(f"Failed: {self.stats['failed']}")
        print(f"Skipped: {self.stats['skipped']}")
        print(f"APT installs: {self.stats['apt']}")
        print(f"PIP installs: {self.stats['pip']}")
        print(f"Git clones: {self.stats['git']}")
        print(f"\nTools installed in: {self.base_dir}")
        print(f"Virtual environments: {self.venv_base}")
        print(f"Log file: {self.log_file}")
        print("="*60)

def main():
    parser = argparse.ArgumentParser(description="Shaurya OS Mass Tool Installer")
    parser.add_argument("--category", "-c", help="Install specific category only")
    parser.add_argument("--workers", "-w", type=int, default=8, help="Parallel workers")
    parser.add_argument("--config", default="tools-manifest.json", help="Config file path")

    args = parser.parse_args()

    installer = ShauryaInstaller(args.config)

    if args.category:
        installer.install_category(args.category, args.workers)
    else:
        installer.install_all(args.workers)

if __name__ == "__main__":
    main()
