#!/bin/bash
# Shaurya OS - XFCE Arabic/English RTL Configuration
# Configures bilingual desktop with proper RTL support

set -e

echo "[+] Configuring Shaurya OS XFCE for Arabic/English..."

# Install required packages
apt-get update
apt-get install -y     xfce4     xfce4-goodies     xfce4-power-manager     xfce4-terminal     xfce4-panel     xfce4-whiskermenu-plugin     xfce4-clipman-plugin     xfce4-screenshooter     xfce4-taskmanager     xfce4-systemload-plugin     xfce4-cpugraph-plugin     xfce4-netload-plugin     xfce4-weather-plugin     xfce4-datetime-plugin     xfce4-battery-plugin     xfce4-pulseaudio-plugin     xfce4-mount-plugin     thunar     thunar-archive-plugin     thunar-volman     mousepad     ristretto     parole     xfce4-notifyd     xfdesktop4     xfwm4     xfce4-session     lightdm     lightdm-gtk-greeter     lightdm-gtk-greeter-settings

# Arabic language support
echo "[+] Installing Arabic language support..."
apt-get install -y     fonts-arabeyes     fonts-noto-arabic     fonts-noto-ui-core     fonts-noto-mono     ibus     ibus-anthy     ibus-m17n     ibus-table     libreoffice-l10n-ar     firefox-esr-l10n-ar     thunderbird-l10n-ar     locales     locales-all

# Configure locales
echo "[+] Configuring locales..."
cat > /etc/locale.gen << 'EOF'
en_US.UTF-8 UTF-8
ar_SA.UTF-8 UTF-8
ar_EG.UTF-8 UTF-8
ar_MA.UTF-8 UTF-8
ar_AE.UTF-8 UTF-8
EOF

locale-gen

# Set default locale
cat > /etc/default/locale << 'EOF'
LANG=en_US.UTF-8
LANGUAGE=en_US:en:ar
LC_CTYPE=en_US.UTF-8
LC_NUMERIC=en_US.UTF-8
LC_TIME=en_US.UTF-8
LC_COLLATE=en_US.UTF-8
LC_MONETARY=en_US.UTF-8
LC_MESSAGES=en_US.UTF-8
LC_PAPER=en_US.UTF-8
LC_NAME=en_US.UTF-8
LC_ADDRESS=en_US.UTF-8
LC_TELEPHONE=en_US.UTF-8
LC_MEASUREMENT=en_US.UTF-8
LC_IDENTIFICATION=en_US.UTF-8
EOF

# Configure IBus for Arabic input
echo "[+] Configuring IBus..."
cat > /etc/xdg/autostart/ibus-daemon.desktop << 'EOF'
[Desktop Entry]
Name=IBus Daemon
Comment=Start IBus daemon for input method
Exec=ibus-daemon --xim --daemonize
Type=Application
X-GNOME-Autostart-Phase=Panel
X-GNOME-AutoRestart=true
X-GNOME-Autostart-Notify=true
EOF

# Create default user config for XFCE with Arabic support
mkdir -p /etc/skel/.config/xfce4/xfconf/xfce-perchannel-xml
mkdir -p /etc/skel/.config/xfce4/panel
mkdir -p /etc/skel/.config/ibus

# XFCE panel configuration with RTL support
cat > /etc/skel/.config/xfce4/xfconf/xfce-perchannel-xml/xfce4-panel.xml << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<channel name="xfce4-panel" version="1.0">
  <property name="configver" type="int" value="2"/>
  <property name="panels" type="array">
    <value type="int" value="1"/>
    <property name="panel-1" type="empty">
      <property name="position" type="string" value="p=6;x=0;y=0"/>
      <property name="length" type="uint" value="100"/>
      <property name="position-locked" type="bool" value="true"/>
      <property name="size" type="uint" value="30"/>
      <property name="plugin-ids" type="array">
        <value type="int" value="1"/>
        <value type="int" value="2"/>
        <value type="int" value="3"/>
        <value type="int" value="4"/>
        <value type="int" value="5"/>
        <value type="int" value="6"/>
        <value type="int" value="7"/>
        <value type="int" value="8"/>
        <value type="int" value="9"/>
        <value type="int" value="10"/>
      </property>
    </property>
  </property>
  <property name="plugins" type="empty">
    <property name="plugin-1" type="string" value="whiskermenu"/>
    <property name="plugin-2" type="string" value="tasklist">
      <property name="group-label" type="uint" value="1"/>
      <property name="flat-buttons" type="bool" value="true"/>
      <property name="show-handle" type="bool" value="true"/>
      <property name="sort-order" type="uint" value="4"/>
      <property name="window-menu" type="bool" value="true"/>
    </property>
    <property name="plugin-3" type="string" value="separator">
      <property name="expand" type="bool" value="true"/>
      <property name="style" type="uint" value="0"/>
    </property>
    <property name="plugin-4" type="string" value="systray">
      <property name="show-frame" type="bool" value="true"/>
      <property name="square-icons" type="bool" value="true"/>
      <property name="known-legacy-items" type="array">
        <value type="string" value="ibus-ui-gtk3"/>
      </property>
    </property>
    <property name="plugin-5" type="string" value="statusnotifier"/>
    <property name="plugin-6" type="string" value="pulseaudio">
      <property name="enable-keyboard-shortcuts" type="bool" value="true"/>
    </property>
    <property name="plugin-7" type="string" value="network-manager"/>
    <property name="plugin-8" type="string" value="power-manager-plugin"/>
    <property name="plugin-9" type="string" value="clock">
      <property name="mode" type="uint" value="2"/>
      <property name="show-frame" type="bool" value="true"/>
      <property name="tooltip-format" type="string" value="%A %d %B %Y"/>
      <property name="digital-format" type="string" value="%I:%M %p"/>
    </property>
    <property name="plugin-10" type="string" value="showdesktop"/>
  </property>
</channel>
EOF

# Desktop configuration
cat > /etc/skel/.config/xfce4/xfconf/xfce-perchannel-xml/xfce4-desktop.xml << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<channel name="xfce4-desktop" version="1.0">
  <property name="backdrop" type="empty">
    <property name="screen0" type="empty">
      <property name="monitor0" type="empty">
        <property name="image-path" type="string" value="/usr/share/shaurya/wallpaper.png"/>
        <property name="image-style" type="int" value="5"/>
        <property name="image-show" type="int" value="1"/>
      </property>
    </property>
  </property>
  <property name="desktop-icons" type="empty">
    <property name="style" type="int" value="2"/>
    <property name="file-icons" type="empty">
      <property name="show-home" type="bool" value="true"/>
      <property name="show-filesystem" type="bool" value="true"/>
      <property name="show-trash" type="bool" value="true"/>
      <property name="show-removable" type="bool" value="true"/>
    </property>
  </property>
</channel>
EOF

# Keyboard configuration with Arabic layout
cat > /etc/skel/.config/xfce4/xfconf/xfce-perchannel-xml/keyboard-layout.xml << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<channel name="keyboard-layout" version="1.0">
  <property name="default" type="empty">
    <property name="xkb-model" type="string" value="pc105"/>
    <property name="xkb-layout" type="string" value="us,ar"/>
    <property name="xkb-variant" type="string" value=","/>
    <property name="xkb-options" type="string" value="grp:alt_shift_toggle,compose:ralt"/>
  </property>
</channel>
EOF

# IBus configuration for Arabic
cat > /etc/skel/.config/ibus/bus/custom.conf << 'EOF'
[engine]
order=ibus-m17n:ar:kbd
preload-engines=ibus-m17n:ar:kbd
EOF

# Window manager configuration
cat > /etc/skel/.config/xfce4/xfconf/xfce-perchannel-xml/xfwm4.xml << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<channel name="xfwm4" version="1.0">
  <property name="general" type="empty">
    <property name="theme" type="string" value="Shaurya-Dark"/>
    <property name="title_font" type="string" value="Noto Sans Bold 10"/>
    <property name="button_layout" type="string" value="O|HMC"/>
    <property name="workspace_count" type="int" value="4"/>
    <property name="placement_mode" type="string" value="center"/>
    <property name="placement_ratio" type="int" value="20"/>
  </property>
</channel>
EOF

# Terminal configuration with Arabic font support
cat > /etc/skel/.config/xfce4/terminal/terminalrc << 'EOF'
[Configuration]
FontName=Noto Mono 10
MiscAlwaysShowTabs=FALSE
MiscBell=FALSE
MiscBellUrgent=FALSE
MiscBordersDefault=TRUE
MiscCursorBlinks=FALSE
MiscCursorShape=TERMINAL_CURSOR_SHAPE_BLOCK
MiscDefaultGeometry=80x24
MiscInheritGeometry=FALSE
MiscMenubarDefault=TRUE
MiscMouseAutohide=FALSE
MiscToolbarDefault=FALSE
MiscConfirmClose=TRUE
MiscCycleTabs=TRUE
MiscTabCloseButtons=TRUE
MiscTabCloseMiddleClick=TRUE
MiscTabPosition=GTK_POS_TOP
MiscHighlightUrls=TRUE
MiscMiddleClickOpensUri=FALSE
MiscCopyOnSelect=FALSE
MiscShowRelaunchDialog=TRUE
MiscRewrapOnResize=TRUE
MiscUseShiftArrowsToScroll=FALSE
MiscSlimTabs=FALSE
MiscNewTabAdjacent=FALSE
MiscSearchDialogOpacity=100
MiscShowUnsafePasteDialog=TRUE
ColorBackground=#1a1a1a
ColorForeground=#ffffff
ColorCursor=#ffffff
ColorPalette=#000000;#cc0000;#4e9a06;#c4a000;#3465a4;#75507b;#06989a;#d3d7cf;#555753;#ef2929;#8ae234;#fce94f;#729fcf;#ad7fa8;#34e2e2;#eeeeec
EOF

# Create Shaurya theme directory
mkdir -p /usr/share/themes/Shaurya-Dark/gtk-3.0
mkdir -p /usr/share/themes/Shaurya-Dark/xfwm4

# Basic GTK theme for Arabic/RTL support
cat > /usr/share/themes/Shaurya-Dark/gtk-3.0/gtk.css << 'EOF'
/* Shaurya OS Dark Theme with RTL Support */
* {
    font-family: "Noto Sans", "Noto Sans Arabic", sans-serif;
    font-size: 10pt;
}

.window-frame {
    box-shadow: 0 3px 7px 1px rgba(0, 0, 0, 0.7);
}

/* RTL Support */
[dir="rtl"] .window-frame {
    text-align: right;
}

/* Dark color scheme */
@define-color bg_color #2d2d2d;
@define-color fg_color #f0f0f0;
@define-color base_color #1a1a1a;
@define-color text_color #ffffff;
@define-color selected_bg_color #4a90d9;
@define-color selected_fg_color #ffffff;
@define-color tooltip_bg_color #f5f5b5;
@define-color tooltip_fg_color #000000;
@define-color error_color #cc0000;
@define-color success_color #4e9a06;
@define-color warning_color #c4a000;
EOF

# Set permissions
chown -R root:root /etc/skel/.config
chmod -R 755 /etc/skel/.config

echo "[✓] XFCE Arabic/English configuration complete!"
echo "[✓] Default locale: en_US.UTF-8 with Arabic support"
echo "[✓] Keyboard: US/Arabic (Alt+Shift to toggle)"
echo "[✓] Theme: Shaurya-Dark with RTL support"
