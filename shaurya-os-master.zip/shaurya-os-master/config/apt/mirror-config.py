#!/usr/bin/env python3
# Shaurya OS - Fast Mirror Configuration
# Automatically selects fastest Kali mirror based on geographic location

import subprocess
import json
import time
import concurrent.futures
from urllib.parse import urlparse
import sys

class FastMirrorSelector:
    def __init__(self):
        # Official Kali mirrors with HTTPS support (2024-2025)
        self.mirrors = {
            "global": [
                "https://kali.download/kali",
                "https://http.kali.org/kali"
            ],
            "north_america": [
                "https://mirrors.ocf.berkeley.edu/kali",
                "https://mirror.vinehost.net/kali",
                "https://mirror.math.princeton.edu/pub/kali",
                "https://mirror.cpsc.ucalgary.ca/mirror/kali.org/kali",
                "https://kali.mirror1.infernocommunity.org/kali"
            ],
            "europe": [
                "https://ftp.halifax.rwth-aachen.de/kali",
                "https://ftp1.nluug.nl/os/Linux/distr/kali",
                "https://ftp2.nluug.nl/os/Linux/distr/kali",
                "https://mirror.neostrada.nl/kali",
                "https://mirrors.dotsrc.org/kali",
                "https://ftp.acc.umu.se/mirror/kali.org/kali",
                "https://mirror.karneval.cz/pub/linux/kali",
                "https://archive-4.kali.org/kali"
            ],
            "asia": [
                "https://mirror.nju.edu.cn/kali",
                "https://mirrors.tuna.tsinghua.edu.cn/kali",
                "https://mirrors.aliyun.com/kali",
                "https://mirror.sg.gs/kali",
                "https://mirror2.amuksa.com/kali",
                "https://mirror.keiminem.com/kali",
                "https://mirror.techlabs.co.kr/kali",
                "https://mirror.hashy0917.net/kali",
                "https://mirrors.nepalicloud.com/kali"
            ],
            "middle_east": [
                "https://mirror.ourhost.az/kali",
                "https://kali.download/kali"  # Cloudflare backed
            ],
            "oceania": [
                "https://wlglam.fsmg.org.nz/kali",
                "https://hlzmel.fsmg.org.nz/kali"
            ]
        }

        self.results = {}

    def test_mirror_speed(self, mirror_url, timeout=5):
        """Test mirror response time and speed"""
        try:
            start_time = time.time()
            test_url = f"{mirror_url}/dists/kali-rolling/main/binary-amd64/Packages.gz"

            result = subprocess.run(
                ["curl", "-o", "/dev/null", "-s", "-w", 
                 "%{http_code},%{size_download},%{time_total},%{speed_download}",
                 "--max-time", str(timeout), test_url],
                capture_output=True, text=True, timeout=timeout+2
            )

            if result.returncode == 0:
                parts = result.stdout.strip().split(',')
                if len(parts) >= 4 and parts[0] == "200":
                    speed = float(parts[3])
                    time_total = float(parts[2])

                    return {
                        "mirror": mirror_url,
                        "response_time": time_total,
                        "speed_bps": speed,
                        "status": "active"
                    }

            return {"mirror": mirror_url, "status": "failed", "error": "No response"}

        except Exception as e:
            return {"mirror": mirror_url, "status": "error", "error": str(e)}

    def find_fastest_in_region(self, region="global", max_workers=5):
        """Find fastest mirror in specified region"""
        mirrors = self.mirrors.get(region, self.mirrors["global"])

        print(f"[+] Testing {len(mirrors)} mirrors in region: {region}")

        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_mirror = {
                executor.submit(self.test_mirror_speed, mirror): mirror 
                for mirror in mirrors
            }

            for future in concurrent.futures.as_completed(future_to_mirror):
                result = future.result()
                self.results[result["mirror"]] = result

                if result["status"] == "active":
                    speed_mbps = result["speed_bps"] / 1024 / 1024
                    print(f"  [OK] {result['mirror']}: {speed_mbps:.2f} MB/s")
                else:
                    print(f"  [FAIL] {result['mirror']}: {result.get('error', 'Failed')}")

        active_mirrors = [r for r in self.results.values() if r["status"] == "active"]

        if not active_mirrors:
            print("[!] No active mirrors found, using default")
            return self.mirrors["global"][0]

        fastest = sorted(active_mirrors, key=lambda x: x["speed_bps"], reverse=True)[0]
        speed_mbps = fastest["speed_bps"] / 1024 / 1024

        print(f"\n[+] Fastest mirror: {fastest['mirror']} ({speed_mbps:.2f} MB/s)")
        return fastest["mirror"]

    def auto_detect_region(self):
        """Auto-detect region based on timezone"""
        try:
            tz_result = subprocess.run(["timedatectl", "show", "--property=Timezone"], 
                                   capture_output=True, text=True)
            if tz_result.returncode == 0:
                tz = tz_result.stdout.strip().split("=")[1]
                if any(x in tz for x in ["America", "US", "Canada"]):
                    return "north_america"
                elif any(x in tz for x in ["Europe"]):
                    return "europe"
                elif any(x in tz for x in ["Asia", "Japan", "Korea", "China", "India", "Singapore"]):
                    return "asia"
                elif any(x in tz for x in ["Dubai", "Abu_Dhabi", "Riyadh", "Cairo", "Tehran", "Istanbul"]):
                    return "middle_east"
                elif any(x in tz for x in ["Australia", "New_Zealand", "Pacific"]):
                    return "oceania"
        except:
            pass
        return "global"

    def generate_sources_list(self, mirror_url, components="main contrib non-free non-free-firmware"):
        """Generate sources.list content"""
        sources = f"""# Shaurya OS - Optimized Mirror Configuration
# Generated automatically for fastest performance
deb {mirror_url} kali-rolling {components}
deb-src {mirror_url} kali-rolling {components}
"""
        return sources

    def apply_configuration(self, mirror_url, backup=True):
        """Apply mirror configuration to system"""
        import shutil
        from datetime import datetime

        sources_file = "/etc/apt/sources.list"

        if backup:
            backup_file = f"/etc/apt/sources.list.bak.{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            shutil.copy2(sources_file, backup_file)
            print(f"[+] Backup created: {backup_file}")

        sources_content = self.generate_sources_list(mirror_url)

        with open(sources_file, 'w') as f:
            f.write(sources_content)

        print(f"[+] Applied configuration to {sources_file}")

        print("[+] Running apt update...")
        result = subprocess.run(["apt-get", "update"], capture_output=True, text=True)
        if result.returncode == 0:
            print("[OK] Configuration applied successfully!")
            return True
        else:
            print(f"[!] apt update failed: {result.stderr}")
            return False

def main():
    selector = FastMirrorSelector()

    print("="*60)
    print("SHAURYA OS - Fast Mirror Configuration")
    print("="*60)

    detected = selector.auto_detect_region()
    print(f"\n[+] Detected region: {detected}")
    print(f"[+] Finding fastest mirror...")

    fastest = selector.find_fastest_in_region(detected)
    selector.apply_configuration(fastest)

if __name__ == "__main__":
    main()
