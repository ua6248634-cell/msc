# Build Instructions for Shaurya OS

## Prerequisites

### Required Packages
```bash
sudo apt update
sudo apt install -y     git live-build simple-cdd cdebootstrap     curl devscripts debootstrap squashfs-tools     xorriso isolinux syslinux-efi     grub-pc-bin grub-efi-amd64-bin     mtools dosfstools parted
```

## Build Steps

### 1. Prepare Environment
```bash
cd shaurya-os-master
sudo ./build-scripts/build.py --prepare
```

### 2. Configure (Optional)
Edit configuration files:
- `config/apt/mirror-config.py` - Mirror settings
- `packages/kali-metapackages/shaurya.list.chroot` - Packages
- `tools-installer/categories/tools-manifest.json` - Tools

### 3. Build ISO
```bash
sudo python3 build-scripts/build.py     --version 1.0.0     --arch amd64     --variant shaurya
```

### 4. Output
ISO will be in `./output/` directory:
- `shaurya-os-1.0.0-amd64.iso`
- `shaurya-os-1.0.0-amd64.iso.sha256sum`

## Build Options

### Fast Build (Minimal)
```bash
# Edit shaurya.list.chroot to include only:
# kali-linux-core
# kali-desktop-xfce
# + essential tools only
```

### Full Build (Complete)
Default configuration includes all 1000+ tools.

### Custom Variant
```bash
# Create new variant
mkdir -p kali-config/variant-custom/package-lists
cp kali-config/variant-shaurya/package-lists/kali.list.chroot    kali-config/variant-custom/package-lists/

# Build
./build.sh --variant custom --verbose
```

## Build Hooks

Hooks execute in order during chroot stage:

1. `01-shaurya-setup.chroot` - SSH, users, passwords
2. `02-fast-mirror.chroot` - Mirror configuration
3. `03-xfce-arabic.chroot` - Desktop environment
4. `04-python-tools.chroot` - 1000+ Python tools
5. `05-radare2.chroot` - Radare2 installation
6. `06-drivers.chroot` - Hardware drivers

## Troubleshooting Builds

### Common Issues

**Issue**: `lb build` fails with "E: Unable to locate package"
- **Fix**: Check internet connection, verify sources.list

**Issue**: Out of space during build
- **Fix**: Ensure 50GB+ free in /tmp and build directory

**Issue**: Mirror slow/unreachable
- **Fix**: Run mirror-config.py to select fastest mirror

**Issue**: Hook script fails
- **Fix**: Check script permissions (must be executable)

### Clean Build
```bash
cd /tmp/live-build-config  # or your build dir
sudo lb clean --purge
sudo rm -rf .build cache
sudo python3 build-scripts/build.py
```

### Debug Build
```bash
# Verbose output
./build.sh --verbose --debug

# Interactive chroot
lb config --interactive true
lb build
```

## Post-Build

### Test ISO
```bash
# QEMU BIOS boot
qemu-system-x86_64 -enable-kvm -m 4096 -cdrom output/shaurya-os-*.iso

# QEMU UEFI boot
qemu-system-x86_64 -enable-kvm -m 4096     -drive if=pflash,format=raw,readonly,file=/usr/share/OVMF/OVMF_CODE.fd     -cdrom output/shaurya-os-*.iso
```

### Create Bootable USB
```bash
# Using dd (destructive)
sudo dd if=output/shaurya-os-*.iso of=/dev/sdX bs=4M status=progress

# Using Ventoy (non-destructive)
# Copy ISO to Ventoy-formatted USB
```

## Advanced

### Custom Kernel
1. Place kernel .deb in `config/packages.chroot/`
2. Add hook to remove default kernel
3. Run `update-initramfs -c -k all`

### Signed ISO
```bash
# Generate GPG key
gpg --full-generate-key

# Sign ISO
gpg --detach-sign --armor output/shaurya-os-*.iso
```

### Network Mirror
For multiple builds, setup local mirror:
```bash
sudo apt install apt-cacher-ng
# Edit /etc/apt-cacher-ng/acng.conf
# Use http://localhost:3142/kali in sources.list
```
