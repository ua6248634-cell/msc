# Customization Guide for Shaurya OS

## Desktop Environment Customization

### XFCE Theme
Edit `config/xfce/arabic-rtl.sh`:

```bash
# Change wallpaper
WALLPAPER_URL="https://your-domain.com/wallpaper.jpg"

# Change theme name
THEME_NAME="YourTheme"

# Modify panel layout
# Edit xfce4-panel.xml section
```

### Keyboard Layouts
Default: US/Arabic (Alt+Shift toggle)

To add more layouts:
```bash
# Edit /etc/skel/.config/xfce4/xfconf/xfce-perchannel-xml/keyboard-layout.xml
<property name="xkb-layout" type="string" value="us,ar,fr,de"/>
```

## Tool Management

### Adding Custom Tools

1. Edit `tools-installer/categories/tools-manifest.json`:
```json
{
  "my_category": {
    "count": 1,
    "tools": [
      {
        "name": "my-tool",
        "repo": "owner/repo",
        "pip": null,
        "apt": null,
        "category": "custom"
      }
    ]
  }
}
```

2. Rebuild ISO

### Removing Tools
Delete entries from `tools-manifest.json` or create exclude list.

## Mirror Configuration

### Static Mirror
Edit `config/apt/mirror-config.py`:
```python
self.mirrors = {
    "custom": ["https://your-mirror.com/kali"]
}
```

### Regional Mirrors
Add to appropriate region:
```python
"asia": [
    "https://your-asia-mirror.com/kali",
    # ... existing mirrors
]
```

## Bootloader Customization

### Splash Screen
Replace `bootloader/shaurya-splash.png`:
- Resolution: 640x480 or 800x600
- Format: PNG
- Keep under 1MB

### Boot Menu Entries
Edit `bootloader/isolinux.cfg` and `bootloader/grub.cfg`:

```bash
LABEL my-custom-boot
    MENU LABEL ^My Custom Boot
    LINUX /live/vmlinuz
    INITRD /live/initrd.img
    APPEND boot=live components quiet splash my-custom-parameter
```

## Preseed Configuration

### Automated Installation
Edit `bootloader/preseed-english.cfg`:

```bash
# Change default password
d-i passwd/root-password password yourpassword
d-i passwd/user-password password yourpassword

# Change hostname
d-i netcfg/get_hostname string myhostname

# Add custom packages
d-i pkgsel/include package1,package2,package3
```

### Arabic Preseed
Edit `bootloader/preseed-arabic.cfg`:
- Locale: `ar_SA.UTF-8`
- Keymap: `ar`
- Timezone: `Asia/Riyadh`

## Build Hooks

### Creating Custom Hooks

1. Create file in `hooks/`:
```bash
#!/bin/bash
set -e

echo "[+] My Custom Hook"
# Your commands here
apt-get install -y my-package
```

2. Make executable:
```bash
chmod +x hooks/99-my-hook.chroot
```

3. Rebuild ISO

### Hook Order
Hooks execute alphabetically:
- `01-basic.chroot`
- `02-network.chroot`
- `99-custom.chroot`

## Driver Customization

### NVIDIA Specific Version
Edit `packages/drivers/nvidia.sh`:
```bash
NVIDIA_VERSION="550.54.14"  # Change version
```

### Skip Drivers
Comment out in `hooks/06-drivers.chroot`:
```bash
# bash /packages/drivers/nvidia.sh || true
```

## Package Selection

### Metapackages
Edit `packages/kali-metapackages/shaurya.list.chroot`:

Minimal:
```
kali-linux-core
kali-desktop-xfce
```

Full:
```
kali-linux-default
kali-tools-top10
kali-linux-headless
kali-tools-web
kali-tools-wireless
# ... all metapackages
```

### Custom Packages
Add to same file:
```
my-custom-package
another-package
```

## Localization

### Adding Languages
Edit `config/locale/locale.gen`:
```
en_US.UTF-8 UTF-8
ar_SA.UTF-8 UTF-8
fr_FR.UTF-8 UTF-8
de_DE.UTF-8 UTF-8
```

### Fonts
Add to `config/xfce/arabic-rtl.sh`:
```bash
apt-get install -y     fonts-noto-cjk     fonts-noto-cjk-extra     fonts-thai-tlwg
```

## Branding

### OS Name
Replace "Shaurya" in:
- `bootloader/isolinux.cfg` (MENU TITLE)
- `bootloader/grub.cfg` (menuentry)
- `build-scripts/build.py` (version strings)

### Icons
Replace in `overlays/usr/share/shaurya/`:
- `logo.svg` - Main logo
- `wallpaper.png` - Default wallpaper

### Theme Colors
Edit GTK theme in `config/xfce/arabic-rtl.sh`:
```css
@define-color selected_bg_color #your-color;
@define-color selected_fg_color #your-color;
```

## Advanced Customization

### Kernel Parameters
Edit boot entries in `bootloader/`:
```bash
APPEND boot=live components quiet splash persistence persistence-encryption=luks
```

### Custom Services
Create systemd service in hook:
```bash
cat > /etc/systemd/system/my-service.service << 'EOF'
[Unit]
Description=My Service
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/my-command
Restart=always

[Install]
WantedBy=multi-user.target
EOF

systemctl enable my-service
```

### Network Configuration
Pre-configure WiFi:
```bash
# In hook script
cat > /etc/NetworkManager/system-connections/my-wifi.nmconnection << 'EOF'
[connection]
id=my-wifi
uuid=...
type=wifi

[wifi]
ssid=MyNetwork

[wifi-security]
key-mgmt=wpa-psk
psk=my-password
EOF

chmod 600 /etc/NetworkManager/system-connections/my-wifi.nmconnection
```

## Testing Changes

### Quick Test
```bash
# Build without full rebuild
sudo lb build noauto
```

### Clean Test
```bash
# Full clean build
sudo lb clean --purge
sudo python3 build-scripts/build.py
```

### QEMU Test
```bash
qemu-system-x86_64 -enable-kvm -m 4096 -cdrom output/shaurya-os-*.iso
```
