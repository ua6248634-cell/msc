# Shaurya OS Tools Documentation

## Overview
Shaurya OS includes 1000+ penetration testing tools organized into 12 categories.

## Tool Categories

### 1. Web Penetration Testing (150 tools)
**Key Tools:**
- **sqlmap** - Automatic SQL injection
- **nuclei** - Fast vulnerability scanner
- **amass** - DNS enumeration and attack surface mapping
- **ffuf** - Fast web fuzzer
- **dirsearch** - Web path scanner
- **burpsuite** - Web proxy (Kali default)
- **wapiti** - Web vulnerability scanner
- **whatweb** - Web scanner
- **wpscan** - WordPress scanner
- **joomscan** - Joomla scanner

**Usage:**
```bash
# SQLMap
sqlmap -u "http://target.com/page.php?id=1" --dbs

# Nuclei
nuclei -u http://target.com -t nuclei-templates/

# Amass
amass enum -d target.com -o amass.txt
```

### 2. Network Penetration Testing (120 tools)
**Key Tools:**
- **impacket** - Python network protocols
- **responder** - LLMNR, NBT-NS and MDNS poisoner
- **mitm6** - IPv6 man-in-the-middle
- **crackmapexec** - SMB enumeration and exploitation
- **enum4linux-ng** - SMB enumeration
- **ldapdomaindump** - LDAP enumeration
- **bloodhound.py** - Active Directory enumeration
- **certipy** - Active Directory Certificate Services abuse

**Usage:**
```bash
# Responder
responder -I eth0 -wrfv

# CrackMapExec
crackmapexec smb 192.168.1.0/24 -u admin -p password

# BloodHound
python3 bloodhound.py -c All -d domain.local -u user -p pass -ns 192.168.1.1
```

### 3. Wireless Penetration Testing (80 tools)
**Key Tools:**
- **aircrack-ng** - WiFi security auditing
- **wifite** - Automated WiFi auditor
- **airgeddon** - Multi-use bash script for WiFi
- **eaphammer** - Evil twin attacks
- **hostapd-wpe** - AP with WPE patches
- **hcxtools** - WiFi capture tools
- **hashcat-utils** - Password cracking utilities
- **reaver** - WPS brute force
- **bully** - WPS brute force alternative
- **wifiphisher** - Rogue AP framework

**Usage:**
```bash
# Aircrack-ng
airmon-ng start wlan0
airodump-ng wlan0mon

# Wifite
wifite --wpa --dict /usr/share/wordlists/rockyou.txt

# EAPHammer
./eaphammer -i wlan0 -c 6 --auth open --essid "Free WiFi" --captive-portal
```

### 4. Mobile Security (60 tools)
**Key Tools:**
- **mobsf** - Mobile Security Framework
- **objection** - Runtime mobile exploration
- **frida-tools** - Dynamic instrumentation
- **androguard** - Android static analysis
- **apktool** - Android APK reverse engineering
- **jadx** - Android decompiler
- **drozer** - Android security assessment
- **qark** - Android vulnerability scanner

**Usage:**
```bash
# MobSF
python3 manage.py runserver 0.0.0.0:8000

# Objection
objection -g com.app.name explore

# Frida
frida -U -f com.app.name -l script.js
```

### 5. Digital Forensics (90 tools)
**Key Tools:**
- **volatility3** - Memory forensics
- **autopsy** - Digital forensics platform
- **sleuthkit** - File system analysis
- **foremost** - File carving
- **bulk_extractor** - Media analysis
- **photorec** - File recovery
- **binwalk** - Firmware analysis
- **yara** - Pattern matching
- **capa** - Capability detection

**Usage:**
```bash
# Volatility3
python3 vol.py -f memory.dmp windows.info

# Autopsy
autopsy &

# Binwalk
binwalk -e firmware.bin
```

### 6. Reverse Engineering (70 tools)
**Key Tools:**
- **radare2** - Reverse engineering framework
- **cutter** - Radare2 GUI
- **rizin** - Reverse engineering framework (fork)
- **ghidra** - NSA reverse engineering tool
- **angr** - Binary analysis framework
- **miasm** - Reverse engineering framework
- **uncompyle6** - Python decompiler
- **pyinstxtractor** - PyInstaller extractor

**Usage:**
```bash
# Radare2
r2 -A /bin/ls
[0x00000000]> pd 10

# Cutter
cutter /path/to/binary

# Ghidra
/opt/ghidra/ghidraRun
```

### 7. Exploitation (100 tools)
**Key Tools:**
- **metasploit** - Exploitation framework
- **beef** - Browser exploitation
- **set** - Social engineering toolkit
- **routersploit** - Router exploitation
- **exploitdb** - Exploit database
- **pwntools** - CTF framework
- **ropgadget** - ROP chain finder
- **one_gadget** - One gadget finder

**Usage:**
```bash
# Metasploit
msfconsole
msf6 > use exploit/multi/handler

# SearchSploit
searchsploit apache 2.4

# Pwntools
python3 exploit.py
```

### 8. Post-Exploitation (80 tools)
**Key Tools:**
- **empire** - PowerShell post-exploitation
- **sliver** - Cross-platform implant
- **havoc** - Modern post-exploitation
- **mythic** - Collaborative red teaming
- **linpeas** - Linux privilege escalation
- **winpeas** - Windows privilege escalation
- **pspy** - Process monitoring
- **gtfobins** - Unix privilege escalation reference

**Usage:**
```bash
# LinPEAS
./linpeas.sh

# Empire
powershell-empire server
powershell-empire client

# Sliver
sliver-server
```

### 9. OSINT (110 tools)
**Key Tools:**
- **theharvester** - Email harvesting
- **maltego** - OSINT visualization
- **spiderfoot** - OSINT automation
- **recon-ng** - Web reconnaissance
- **osrframework** - Username checking
- **twint** - Twitter intelligence
- **sherlock** - Username enumeration
- **holehe** - Email checking
- **ghunt** - Google account investigation

**Usage:**
```bash
# TheHarvester
theHarvester -d target.com -b all

# Sherlock
sherlock username

# SpiderFoot
python3 sf.py -l 127.0.0.1:5001
```

### 10. Cloud Penetration Testing (70 tools)
**Key Tools:**
- **cloudmapper** - AWS environment visualization
- **prowler** - AWS security assessment
- **pacu** - AWS exploitation
- **cloudsplaining** - AWS IAM analysis
- **roadrecon** - Azure AD reconnaissance
- **azurehound** - Azure data collector
- **gcpbucketbrute** - GCP bucket enumeration
- **cloudfox** - AWS enumeration

**Usage:**
```bash
# Prowler
./prowler -c check11

# Pacu
python3 pacu.py

# CloudMapper
python3 cloudmapper.py prepare --account-id 123456789
```

### 11. Steganography (40 tools)
**Key Tools:**
- **steghide** - Hide data in images
- **stegseek** - Steghide cracker
- **zsteg** - PNG/BMP steganography
- **stegsolve** - Steganography solver
- **stegoveritas** - Automated steg analysis
- **outguess** - Universal steganography
- **spectrology** - Audio spectrograms

**Usage:**
```bash
# Steghide
steghide embed -cf image.jpg -ef secret.txt
steghide extract -sf image.jpg

# Zsteg
zsteg image.png

# StegSeek
stegseek image.jpg wordlist.txt
```

### 12. Reporting (50 tools)
**Key Tools:**
- **dradis** - Collaboration platform
- **faraday** - Vulnerability management
- **defectdojo** - Vulnerability tracker
- **serpico** - Report generator
- **writehat** - Reporting tool
- **pwndoc** - Pentest reporting
- **ghostwriter** - Reporting platform

**Usage:**
```bash
# Faraday
faraday-server
faraday-client

# Dradis
ruby bin/rails server
```

## Tool Locations

### APT Installed
```
/usr/bin/
/usr/share/
/opt/
```

### Git Cloned
```
/opt/shaurya-tools/<category>/<tool-name>/
```

### Python Virtual Envs
```
/opt/shaurya-venvs/<category>-<tool>/
```

## Updating Tools

### APT Tools
```bash
sudo apt update && sudo apt upgrade
```

### Git Tools
```bash
cd /opt/shaurya-tools/category/tool-name
git pull
```

### Python Tools
```bash
source /opt/shaurya-venvs/category-tool/bin/activate
pip install --upgrade tool-name
deactivate
```

## Adding New Tools

1. Edit `tools-manifest.json`
2. Run installer:
```bash
sudo python3 /tools-installer/scripts/mass-installer.py --category new-category
```

## Tool Support

For tool-specific help:
```bash
# Most tools have help
<tool> --help
<tool> -h

# Or man pages
man <tool>
```
