# Shaurya OS - Master Build Package

## Overview
**Shaurya OS** is a custom Kali Linux-based penetration testing distribution featuring:
- **XFCE Desktop** with custom Shaurya theme
- **Arabic & English** bilingual support with RTL
- **1000+ Python tools** from GitHub (automated installation)
- **Fast mirror** configuration (auto-detected by region)
- **Complete driver support** (NVIDIA, AMD, Intel)
- **Latest radare2** with all plugins
- **Bootable ISO** with live and install modes

## Package Structure
```
shaurya-os-master/
├── build-scripts/
│   ├── build.py              # Main Python build script
│   ├── shaurya-builder.sh    # Bash build wrapper
│   └── mirror-config.py      # Fast mirror selector
├── config/
│   ├── xfce/
│   │   └── arabic-rtl.sh     # XFCE Arabic/English config
│   ├── apt/
│   │   └── mirror-config.py  # Mirror speed tester
│   └── locale/
│       └── locale.gen        # Locale configuration
├── packages/
│   ├── python-tools/
│   │   ├── tools-manifest.json    # 1000+ tools database
│   │   └── install-python-tools.py # Mass installer
│   ├── kali-metapackages/
│   │   └── shaurya.list.chroot    # Package list
│   └── drivers/
│       ├── nvidia.sh         # NVIDIA driver installer
│       ├── intel.sh          # Intel driver installer
│       ├── amd.sh            # AMD driver installer
│       └── radare2.sh        # Radare2 installer
├── hooks/
│   ├── 01-shaurya-setup.chroot
│   ├── 02-fast-mirror.chroot
│   ├── 03-xfce-arabic.chroot
│   ├── 04-python-tools.chroot
│   ├── 05-radare2.chroot
│   └── 06-drivers.chroot
├── bootloader/
│   ├── isolinux.cfg          # BIOS boot menu
│   ├── grub.cfg              # UEFI boot menu
│   ├── preseed-english.cfg   # Unattended install (EN)
│   └── preseed-arabic.cfg    # Unattended install (AR)
└── docs/
    ├── BUILD.md              # Build instructions
    ├── CUSTOMIZE.md          # Customization guide
    └── TOOLS.md              # Tools documentation
```

## Quick Start

### 1. Extract and Setup
```bash
cd shaurya-os-master
chmod +x build-scripts/*.py build-scripts/*.sh hooks/*.chroot
```

### 2. Configure Fast Mirror (Optional)
```bash
sudo python3 config/apt/mirror-config.py
```

### 3. Build ISO
```bash
sudo python3 build-scripts/build.py --version 1.0.0
```

## System Requirements

### Build Machine:
- **OS**: Kali Linux (recommended) or Debian-based
- **RAM**: 8GB minimum (16GB recommended)
- **Storage**: 50GB free space
- **Architecture**: amd64 (x86_64)

### Target System:
- **CPU**: 64-bit processor
- **RAM**: 4GB minimum (8GB recommended)
- **Storage**: 20GB for installation
- **Graphics**: NVIDIA/AMD/Intel GPU support included

## Features

### Desktop Environment
- **XFCE 4.18+** with custom Shaurya dark theme
- **Arabic RTL** support with proper fonts
- **Keyboard**: US/Arabic toggle (Alt+Shift)
- **Panel**: Custom layout with system monitors

### Pre-installed Tools (1000+)
Categories include:
- Web Penetration Testing (150 tools)
- Network Penetration Testing (120 tools)
- Wireless Penetration Testing (80 tools)
- Mobile Security (60 tools)
- Digital Forensics (90 tools)
- Reverse Engineering (70 tools)
- Exploitation Frameworks (100 tools)
- Post-Exploitation (80 tools)
- OSINT (110 tools)
- Cloud Penetration Testing (70 tools)
- Steganography (40 tools)
- Reporting Tools (50 tools)

### Drivers
- **NVIDIA**: Latest drivers with CUDA support
- **AMD**: AMDGPU with ROCm support
- **Intel**: Intel Media drivers with OpenCL
- **Wireless**: All major chipset firmware

## Build Process

The build uses Kali's official live-build system with custom hooks:

1. **Bootstrap**: Base Kali system
2. **Chroot**: Install packages and tools
3. **Hooks**: Run customization scripts
4. **Binary**: Create bootable ISO

## Customization

### Adding Tools
Edit `tools-installer/categories/tools-manifest.json`:
```json
{
  "category_name": {
    "count": N,
    "tools": [
      {
        "name": "tool-name",
        "repo": "owner/repo",
        "pip": "package-name",
        "apt": "package-name",
        "category": "subcategory"
      }
    ]
  }
}
```

### Changing Theme
Modify files in `config/xfce/`:
- `arabic-rtl.sh` - Desktop configuration
- `panel-config.xml` - Panel layout
- `shaurya-theme.tar.gz` - GTK theme

### Mirror Selection
The mirror config automatically tests:
- Global CDN (kali.download)
- Regional mirrors (NA, EU, Asia, Middle East)
- Selects fastest based on download speed

## Installation Modes

### Live Boot
- Boot without installation
- Persistence support (encrypted available)
- Forensics mode (no automount)

### Install Options
- English (default)
- Arabic (RTL layout)
- Unattended (preseed)

## Post-Installation

### First Boot
1. Login: `shaurya` / `shaurya` (or root / shaurya)
2. Change passwords: `passwd` and `sudo passwd shaurya`
3. Update system: `sudo apt update && sudo apt upgrade`

### Tool Locations
- APT installed: `/usr/bin/`, `/usr/share/`
- Git cloned: `/opt/shaurya-tools/<category>/`
- Python venv: `/opt/shaurya-venvs/`

## Troubleshooting

### Build Fails
- Check internet connection
- Ensure 50GB+ free space
- Run `lb clean --purge` before rebuild

### Slow Downloads
- Run `sudo python3 config/apt/mirror-config.py`
- Use local mirror if available
- Consider `apt-cacher-ng` for multiple builds

### Missing Drivers
- Run driver scripts manually:
  ```bash
  sudo bash packages/drivers/nvidia.sh
  sudo bash packages/drivers/intel.sh
  sudo bash packages/drivers/amd.sh
  ```

## Security Notes

- Default passwords should be changed immediately
- SSH is enabled by default (change config in 01-shaurya-setup.chroot)
- Root login is enabled (disable for production)

## Credits

- Based on Kali Linux by Offensive Security
- Uses Debian Live Build system
- Tools curated from GitHub security community

## License

This build system is provided as-is for educational and authorized testing purposes only.

---
**Shaurya OS** - Advanced Penetration Testing Platform
Built with Kali Linux Live Build System
