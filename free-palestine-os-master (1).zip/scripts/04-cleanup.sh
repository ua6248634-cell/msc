#!/bin/bash
set -e

echo "[*] Free Palestine OS - Build Cleanup"
echo ""

cd ~/free-palestine-os

echo "[*] Stopping any running build processes..."
pkill -f "lb build" 2>/dev/null || true
pkill -f "lb bootstrap" 2>/dev/null || true
pkill -f "lb chroot" 2>/dev/null || true

echo "[*] Cleaning build artifacts..."
lb clean --purge 2>/dev/null || true

echo "[*] Removing old ISO files..."
rm -f *.iso 2>/dev/null || true
rm -f live-image-* 2>/dev/null || true

echo "[*] Cleaning cache directories..."
rm -rf cache/* 2>/dev/null || true
rm -rf .build/ 2>/dev/null || true

echo "[*] Cleaning chroot..."
rm -rf chroot/ 2>/dev/null || true
rm -rf binary/ 2>/dev/null || true

echo "[*] Cleaning temporary files..."
rm -f *.log 2>/dev/null || true
rm -f *.tmp 2>/dev/null || true

echo ""
echo "[+] Cleanup complete!"
echo "[*] You can now start a fresh build with:"
echo "    sudo ./scripts/02-build-iso.sh"
