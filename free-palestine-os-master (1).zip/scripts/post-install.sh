#!/bin/bash
# Free Palestine OS - Post Installation Configuration
# Run this after installing to hard drive

set -e

echo "=========================================="
echo "  Free Palestine OS - Post Install Setup"
echo "=========================================="
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "Please run as root (sudo)"
    exit 1
fi

echo "[*] Updating system..."
apt-get update
apt-get upgrade -y

echo "[*] Installing additional firmware..."
apt-get install -y \
    firmware-linux \
    firmware-linux-nonfree \
    firmware-misc-nonfree \
    firmware-realtek \
    firmware-atheros \
    firmware-brcm80211 \
    firmware-iwlwifi \
    firmware-intelwimax \
    firmware-libertas \
    firmware-ti-connectivity \
    firmware-zd1211 \
    firmware-qlogic \
    firmware-bnx2 \
    firmware-bnx2x \
    firmware-cavium || true

echo "[*] Configuring firewall..."
apt-get install -y ufw
ufw default deny incoming
ufw default allow outgoing
ufw allow ssh
ufw enable || true

echo "[*] Setting up automatic updates..."
apt-get install -y unattended-upgrades
systemctl enable unattended-upgrades

echo "[*] Optimizing system for desktop use..."
# Disable unnecessary services
systemctl disable bluetooth 2>/dev/null || true
systemctl disable cups-browsed 2>/dev/null || true

echo "[*] Creating user directories..."
mkdir -p /home/palestine/Documents
mkdir -p /home/palestine/Downloads
mkdir -p /home/palestine/Desktop
mkdir -p /home/palestine/Tools
chown -R palestine:palestine /home/palestine

echo "[*] Setting up tool shortcuts..."
ln -sf /opt/security-tools /home/palestine/Tools/security-tools
chown -R palestine:palestine /home/palestine/Tools

echo ""
echo "[+] Post-installation setup complete!"
echo ""
echo "Recommended next steps:"
echo "  1. Change default passwords: passwd and sudo passwd"
echo "  2. Configure network: nmcli or GUI"
echo "  3. Install additional software as needed"
echo "  4. Check /opt/security-tools/ for security tools"
echo ""
echo "Enjoy Free Palestine OS!"
