#!/bin/bash
set -e

cd ~/free-palestine-os

echo "=========================================="
echo "  Free Palestine OS - Build Script"
echo "  Version 1.0 - Fixed Edition"
echo "=========================================="
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "[-] Please run as root (use sudo)"
    exit 1
fi

echo "[*] Starting build process..."
echo "[*] This will take 3-6 hours depending on your system"
echo ""

# Clean previous builds
if [ -f "live-image-amd64.hybrid.iso" ]; then
    echo "[*] Cleaning previous build..."
    rm -f live-image-amd64.hybrid.iso
fi

# Clean cache if needed
echo "[*] Cleaning build cache..."
lb clean --purge 2>/dev/null || true

# Copy hooks to proper location
echo "[*] Setting up build configuration..."
mkdir -p config/hooks/normal
mkdir -p config/hooks/binary
mkdir -p config/archives
mkdir -p config/package-lists

# Ensure all hooks are executable
chmod +x config/hooks/normal/*.chroot 2>/dev/null || true
chmod +x config/hooks/binary/*.binary 2>/dev/null || true

# Configure build
echo "[*] Configuring live-build..."
lb config

# Start build with error handling
echo "[*] Starting ISO build..."
echo "[*] Phase 1: Bootstrap (this takes a while)..."

if ! lb bootstrap; then
    echo "[-] Bootstrap failed - checking for errors..."
    # Try to fix common errors
    echo "[*] Attempting to fix package errors..."

    # Update package lists
    apt-get update || true

    # Continue build
    lb bootstrap || {
        echo "[-] Bootstrap failed again. Check logs in .build/"
        exit 1
    }
fi

echo "[*] Phase 2: Building chroot environment..."
if ! lb chroot; then
    echo "[-] Chroot build failed - attempting to continue..."
fi

echo "[*] Phase 3: Installing packages..."
if ! lb chroot_install; then
    echo "[-] Package installation had errors - continuing..."
fi

echo "[*] Phase 4: Running hooks..."
lb chroot_hooks || echo "[-] Some hooks failed - continuing..."

echo "[*] Phase 5: Preparing binary image..."
lb binary || {
    echo "[-] Binary preparation failed"
    exit 1
}

echo "[*] Phase 6: Generating ISO..."
lb binary_iso || {
    echo "[-] ISO generation failed"
    exit 1
}

# Rename output ISO
if [ -f "live-image-amd64.hybrid.iso" ]; then
    mv live-image-amd64.hybrid.iso free-palestine-os-v1.0-amd64.iso

    echo ""
    echo "=========================================="
    echo "[+] BUILD SUCCESSFUL!"
    echo "=========================================="
    echo ""
    echo "ISO File: free-palestine-os-v1.0-amd64.iso"
    echo "Size: $(du -h free-palestine-os-v1.0-amd64.iso | cut -f1)"
    echo "SHA256: $(sha256sum free-palestine-os-v1.0-amd64.iso | cut -d' ' -f1)"
    echo ""
    echo "Default Credentials:"
    echo "  Username: palestine"
    echo "  Password: freepalestine123"
    echo "  Root: root123"
    echo ""
    echo "Features:"
    echo "  - Light Theme (Arc + Papyrus)"
    echo "  - 20000+ Security Tools"
    echo "  - Kali Linux Repository"
    echo "  - Radare2 + Ghidra + Cutter"
    echo "  - Full Development Environment"
    echo "  - Bootable for Physical Install"
    echo ""
    echo "To create bootable USB:"
    echo "  sudo dd if=free-palestine-os-v1.0-amd64.iso of=/dev/sdX bs=4M status=progress"
    echo ""
else
    echo "[-] ISO file not found - build may have failed"
    exit 1
fi
