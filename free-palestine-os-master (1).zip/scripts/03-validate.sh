#!/bin/bash
set -e

echo "=========================================="
echo "  Free Palestine OS - Build Validator"
echo "=========================================="
echo ""

cd ~/free-palestine-os

ERRORS=0
WARNINGS=0

check_file() {
    if [ -f "$1" ]; then
        echo "  [✓] $1"
        return 0
    else
        echo "  [✗] MISSING: $1"
        ((ERRORS++))
        return 1
    fi
}

check_dir() {
    if [ -d "$1" ]; then
        echo "  [✓] $1/"
        return 0
    else
        echo "  [✗] MISSING: $1/"
        ((ERRORS++))
        return 1
    fi
}

check_executable() {
    if [ -f "$1" ] && [ -x "$1" ]; then
        echo "  [✓] $1 (executable)"
        return 0
    else
        echo "  [✗] NOT EXECUTABLE: $1"
        ((ERRORS++))
        return 1
    fi
}

echo "[*] Checking directory structure..."
check_dir "config"
check_dir "config/auto"
check_dir "config/archives"
check_dir "config/hooks"
check_dir "config/hooks/normal"
check_dir "config/hooks/binary"
check_dir "config/package-lists"
check_dir "scripts"
check_dir "docs"

echo ""
echo "[*] Checking essential configuration files..."
check_file "config/auto/config"
check_file "config/archives/kali.list.chroot"
check_file "config/archives/kali-archive-keyring.asc.chroot"

echo ""
echo "[*] Checking package lists..."
check_file "config/package-lists/core.list.chroot"
check_file "config/package-lists/security.list.chroot"
check_file "config/package-lists/dev.list.chroot"

echo ""
echo "[*] Checking build scripts..."
check_executable "scripts/01-setup-build-env.sh"
check_executable "scripts/02-build-iso.sh"

echo ""
echo "[*] Checking hooks (normal)..."
for hook in config/hooks/normal/*.chroot; do
    if [ -f "$hook" ]; then
        if [ -x "$hook" ]; then
            echo "  [✓] $(basename $hook) (executable)"
        else
            echo "  [!] $(basename $hook) (not executable)"
            ((WARNINGS++))
        fi
    fi
done

echo ""
echo "[*] Checking hooks (binary)..."
for hook in config/hooks/binary/*.binary; do
    if [ -f "$hook" ]; then
        if [ -x "$hook" ]; then
            echo "  [✓] $(basename $hook) (executable)"
        else
            echo "  [!] $(basename $hook) (not executable)"
            ((WARNINGS++))
        fi
    fi
done

echo ""
echo "[*] Checking documentation..."
check_file "README.md"
check_file "QUICKREF.md"
check_file "BUILD_NOTES.md"
check_file "docs/INSTALL.md"
check_file "docs/TROUBLESHOOTING.md"

echo ""
echo "[*] Validating configuration syntax..."

# Check auto/config
if bash -n config/auto/config 2>/dev/null; then
    echo "  [✓] config/auto/config (syntax OK)"
else
    echo "  [✗] config/auto/config (syntax errors)"
    ((ERRORS++))
fi

# Check build scripts
if bash -n scripts/01-setup-build-env.sh 2>/dev/null; then
    echo "  [✓] scripts/01-setup-build-env.sh (syntax OK)"
else
    echo "  [✗] scripts/01-setup-build-env.sh (syntax errors)"
    ((ERRORS++))
fi

if bash -n scripts/02-build-iso.sh 2>/dev/null; then
    echo "  [✓] scripts/02-build-iso.sh (syntax OK)"
else
    echo "  [✗] scripts/02-build-iso.sh (syntax errors)"
    ((ERRORS++))
fi

echo ""
echo "[*] Checking for common issues..."

# Check for unavailable packages in lists
if grep -q "^radare2$" config/package-lists/*.list.chroot 2>/dev/null; then
    echo "  [!] radare2 found in package lists (should be installed from GitHub)"
    ((WARNINGS++))
else
    echo "  [✓] radare2 not in package lists (correct)"
fi

if grep -q "^exploitdb$" config/package-lists/*.list.chroot 2>/dev/null; then
    echo "  [!] exploitdb found in package lists (should be installed from GitHub)"
    ((WARNINGS++))
else
    echo "  [✓] exploitdb not in package lists (correct)"
fi

if grep -q "^python3-crypto$" config/package-lists/*.list.chroot 2>/dev/null; then
    echo "  [!] python3-crypto found in package lists (obsolete package)"
    ((WARNINGS++))
else
    echo "  [✓] python3-crypto not in package lists (correct)"
fi

if grep -q "^xfce4-screensaver$" config/package-lists/*.list.chroot 2>/dev/null; then
    echo "  [!] xfce4-screensaver found in package lists (unavailable)"
    ((WARNINGS++))
else
    echo "  [✓] xfce4-screensaver not in package lists (correct)"
fi

echo ""
echo "=========================================="
if [ $ERRORS -eq 0 ] && [ $WARNINGS -eq 0 ]; then
    echo "  [✓] VALIDATION PASSED"
    echo "      All checks passed, ready to build!"
elif [ $ERRORS -eq 0 ]; then
    echo "  [!] VALIDATION PASSED WITH WARNINGS"
    echo "      $WARNINGS warning(s) found, but build should work"
else
    echo "  [✗] VALIDATION FAILED"
    echo "      $ERRORS error(s) and $WARNINGS warning(s) found"
    echo "      Please fix errors before building"
    exit 1
fi
echo "=========================================="

exit 0
