#!/bin/bash
set -e

# Free Palestine OS - Master Build Script
# This script orchestrates the entire build process

VERSION="1.0"
CODENAME="Al-Quds"
BUILD_DATE=$(date +%Y%m%d)

# Colors for output
RED='[0;31m'
GREEN='[0;32m'
YELLOW='[1;33m'
BLUE='[0;34m'
NC='[0m' # No Color

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

show_banner() {
    clear
    echo "=========================================="
    echo "  Free Palestine OS - Build System"
    echo "  Version: $VERSION ($CODENAME)"
    echo "  Build Date: $BUILD_DATE"
    echo "=========================================="
    echo ""
}

show_menu() {
    echo "Select an option:"
    echo ""
    echo "  1) Full Build (Setup + Build + Validate)"
    echo "  2) Setup Build Environment Only"
    echo "  3) Build ISO Only (requires setup)"
    echo "  4) Validate Build Configuration"
    echo "  5) Cleanup Build Environment"
    echo "  6) Quick Build (Skip GitHub tools)"
    echo "  7) Exit"
    echo ""
}

run_setup() {
    log_info "Setting up build environment..."
    if sudo ./scripts/01-setup-build-env.sh; then
        log_success "Setup complete"
        return 0
    else
        log_error "Setup failed"
        return 1
    fi
}

run_build() {
    log_info "Starting ISO build..."
    log_info "This will take 3-6 hours depending on your system"
    log_info "Press Ctrl+C to cancel at any time"
    echo ""
    sleep 3

    if sudo ./scripts/02-build-iso.sh; then
        log_success "Build complete"
        return 0
    else
        log_error "Build failed"
        return 1
    fi
}

run_quick_build() {
    log_info "Starting QUICK build (GitHub tools will be skipped)..."
    export SKIP_GITHUB=1

    if sudo ./scripts/02-build-iso.sh; then
        log_success "Quick build complete"
        log_warning "GitHub tools were skipped. Install manually later if needed."
        return 0
    else
        log_error "Quick build failed"
        return 1
    fi
}

run_validate() {
    log_info "Validating build configuration..."
    if ./scripts/03-validate.sh; then
        log_success "Validation passed"
        return 0
    else
        log_error "Validation failed"
        return 1
    fi
}

run_cleanup() {
    log_info "Cleaning up build environment..."
    if ./scripts/04-cleanup.sh; then
        log_success "Cleanup complete"
        return 0
    else
        log_error "Cleanup failed"
        return 1
    fi
}

full_build() {
    log_info "Starting FULL BUILD process..."
    echo ""

    # Step 1: Validate
    if ! run_validate; then
        log_error "Validation failed, aborting"
        exit 1
    fi

    # Step 2: Setup
    if ! run_setup; then
        log_error "Setup failed, aborting"
        exit 1
    fi

    # Step 3: Build
    if ! run_build; then
        log_error "Build failed"
        exit 1
    fi

    log_success "FULL BUILD completed successfully!"
    echo ""
    echo "Your ISO is ready: free-palestine-os-v${VERSION}-amd64.iso"
    echo ""
    echo "Next steps:"
    echo "  1. Test the ISO in a VM"
    echo "  2. Create bootable USB: sudo dd if=*.iso of=/dev/sdX bs=4M"
    echo "  3. Install on physical hardware"
}

# Main execution
cd ~/free-palestine-os

show_banner

# Check if running as root for certain operations
if [ "$EUID" -eq 0 ]; then 
    log_error "This script should not be run as root directly"
    log_info "It will use sudo when needed"
    exit 1
fi

# Check if we're in the right directory
if [ ! -f "README.md" ] || [ ! -d "scripts" ]; then
    log_error "Please run this script from the free-palestine-os directory"
    exit 1
fi

show_menu
read -p "Enter choice [1-7]: " choice

case $choice in
    1)
        full_build
        ;;
    2)
        run_setup
        ;;
    3)
        run_build
        ;;
    4)
        run_validate
        ;;
    5)
        run_cleanup
        ;;
    6)
        run_quick_build
        ;;
    7)
        log_info "Exiting..."
        exit 0
        ;;
    *)
        log_error "Invalid choice"
        exit 1
        ;;
esac
