# Troubleshooting Guide - Free Palestine OS

## Common Issues and Solutions

### 1. Boot Problems

#### Issue: "Operating System not found" or "No bootable device"
**Solutions:**
- Verify USB was created correctly (re-flash if needed)
- Check BIOS boot order (USB should be first)
- Try different USB port (preferably USB 2.0)
- Disable Secure Boot in BIOS
- Enable Legacy/CSM mode

#### Issue: Black screen after selecting boot option
**Solutions:**
1. At GRUB menu, press `e` to edit
2. Find line starting with `linux`
3. Add `nomodeset` after `quiet splash`
4. Press F10 to boot

**Alternative kernel parameters:**
- `nomodeset` - Disable kernel mode setting
- `nouveau.modeset=0` - Disable Nouveau (NVIDIA)
- `i915.modeset=0` - Disable Intel graphics
- `radeon.modeset=0` - Disable Radeon
- `acpi=off` - Disable ACPI
- `noapic` - Disable APIC
- `nolapic` - Disable local APIC

#### Issue: Stuck at "Loading initial ramdisk"
**Solutions:**
- Add `rootdelay=10` to kernel parameters
- Try different USB drive
- Check ISO integrity (SHA256)

### 2. Graphics Issues

#### Issue: Low resolution or wrong display
**Solutions:**
```bash
# Install graphics drivers
sudo apt update
sudo apt install xserver-xorg-video-all

# For NVIDIA:
sudo apt install nvidia-driver

# For AMD:
sudo apt install xserver-xorg-video-amdgpu

# For Intel:
sudo apt install xserver-xorg-video-intel

# Reboot
sudo reboot
```

#### Issue: Screen tearing
**Solutions:**
```bash
# Create X11 config
sudo nano /etc/X11/xorg.conf.d/20-intel.conf
```
Add:
```
Section "Device"
    Identifier "Intel Graphics"
    Driver "intel"
    Option "TearFree" "true"
EndSection
```

### 3. Network Issues

#### Issue: No Wi-Fi detected
**Solutions:**
```bash
# Check wireless interface
ip link show

# Check if blocked
rfkill list
rfkill unblock all

# Install firmware
sudo apt install firmware-iwlwifi firmware-realtek

# Restart NetworkManager
sudo systemctl restart NetworkManager
```

#### Issue: Cannot connect to Wi-Fi
**Solutions:**
```bash
# Using nmcli
nmcli device wifi list
nmcli device wifi connect "SSID" password "password"

# Check for MAC address randomization
sudo nano /etc/NetworkManager/NetworkManager.conf
```
Add:
```
[device]
wifi.scan-rand-mac-address=no
```

### 4. Package Installation Errors

#### Issue: "Package has no installation candidate"
**Solutions:**
- This is expected for some packages (radare2, exploitdb)
- These are installed from GitHub instead
- Check `/opt/security-tools/` directory

#### Issue: Broken dependencies
**Solutions:**
```bash
# Fix broken packages
sudo apt --fix-broken install
sudo dpkg --configure -a
sudo apt update
sudo apt upgrade

# Clean package cache
sudo apt clean
sudo apt autoclean
sudo apt autoremove
```

#### Issue: Hash sum mismatch
**Solutions:**
```bash
# Clear cache and update
sudo rm -rf /var/lib/apt/lists/*
sudo apt clean
sudo apt update
```

### 5. Performance Issues

#### Issue: Slow boot time
**Solutions:**
```bash
# Analyze boot
systemd-analyze blame

# Disable unnecessary services
sudo systemctl disable bluetooth  # If not needed
sudo systemctl disable cups       # If not printing

# Clean logs
sudo journalctl --vacuum-time=3d
```

#### Issue: High memory usage
**Solutions:**
```bash
# Check memory usage
free -h
htop

# Disable unnecessary startup apps
# XFCE: Settings > Session and Startup
```

### 6. Persistence Issues

#### Issue: Changes not saved in live mode
**Solutions:**
1. Create persistence partition (see INSTALL.md)
2. Boot with `persistence` parameter
3. Check persistence is mounted:
   ```bash
   mount | grep persistence
   ```

#### Issue: Persistence partition not recognized
**Solutions:**
- Ensure partition is labeled exactly `persistence`
- Filesystem must be ext4
- `persistence.conf` must exist with `/ union`
- Try `persistence-encryption=luks` for encrypted persistence

### 7. Tool-Specific Issues

#### Issue: Metasploit database not connected
**Solutions:**
```bash
# Initialize database
sudo msfdb init

# Start service
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Reinitialize if needed
sudo msfdb reinit
```

#### Issue: Wireshark permissions
**Solutions:**
```bash
# Add user to wireshark group
sudo usermod -aG wireshark palestine

# Set dumpcap permissions
sudo setcap cap_net_raw,cap_net_admin=eip /usr/bin/dumpcap

# Logout and login again
```

#### Issue: Burp Suite won't start
**Solutions:**
```bash
# Check Java version
java -version

# Install if needed
sudo apt install default-jre

# Run from terminal to see errors
burpsuite
```

### 8. Sound Issues

#### Issue: No audio output
**Solutions:**
```bash
# Check volume
alsamixer

# Check audio service
sudo systemctl status pulseaudio

# Restart audio
pulseaudio -k
pulseaudio --start

# Select output device
pavucontrol
```

### 9. Keyboard/Input Issues

#### Issue: Wrong keyboard layout
**Solutions:**
```bash
# Set layout
setxkbmap us  # or your layout

# For Arabic
setxkbmap ara

# Permanently
sudo dpkg-reconfigure keyboard-configuration
```

#### Issue: Touchpad not working
**Solutions:**
```bash
# Check if detected
xinput list

# Enable
xinput set-prop "SynPS/2 Synaptics TouchPad" "Device Enabled" 1
```

### 10. Recovery Procedures

#### Reset forgotten password
1. Boot from USB
2. Select "Advanced options"
3. Select "Recovery mode"
4. Select "Root shell"
5. Mount filesystem: `mount -o remount,rw /`
6. Reset password: `passwd palestine`

#### Repair GRUB
```bash
# Boot from USB
# Open terminal
sudo mount /dev/sdXn /mnt  # Your root partition
sudo grub-install --boot-directory=/mnt/boot /dev/sdX
sudo update-grub
```

#### Check filesystem
```bash
# Boot from USB
# Check partition
sudo fsck -y /dev/sdXn
```

## Getting More Help

### Log Files
Check these logs for errors:
```bash
# System logs
sudo journalctl -xe

# X11 logs
cat /var/log/Xorg.0.log

# Boot logs
sudo dmesg | less

# Package logs
cat /var/log/dpkg.log
```

### Safe Mode Boot
1. At GRUB, select "Advanced options"
2. Select "Recovery mode"
3. Choose:
   - **fsck**: Check filesystems
   - **clean**: Clean package cache
   - **dpkg**: Fix broken packages
   - **root**: Root shell for manual fixes

### Factory Reset (Live USB)
If installed system is broken:
1. Boot from USB
2. Choose "Install" to reinstall
3. Select existing partitions to overwrite

### Community Resources
- Debian Wiki: https://wiki.debian.org
- Kali Docs: https://www.kali.org/docs/
- XFCE Docs: https://docs.xfce.org

### Bug Reports
If you find a bug specific to Free Palestine OS:
1. Check if it's a Debian/Kali issue first
2. Document steps to reproduce
3. Include system information: `inxi -Fxz`
4. Report to project maintainers

---
**Remember**: Always backup important data before making system changes!
