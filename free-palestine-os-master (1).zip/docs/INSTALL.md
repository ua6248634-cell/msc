# Installation Guide - Free Palestine OS

## Table of Contents
1. [System Requirements](#system-requirements)
2. [Creating Bootable Media](#creating-bootable-media)
3. [Installation Options](#installation-options)
4. [Post-Installation](#post-installation)
5. [Troubleshooting](#troubleshooting)

## System Requirements

### Minimum Requirements
- CPU: 64-bit (x86_64) processor
- RAM: 4 GB
- Storage: 20 GB free space
- Display: 1024x768 resolution
- USB: 2.0 port (3.0 recommended)

### Recommended Requirements
- CPU: Multi-core processor (i5/i7 or Ryzen)
- RAM: 8 GB or more
- Storage: 50 GB SSD
- Display: 1920x1080 or higher
- USB: 3.0 port
- Network: Internet connection for updates

## Creating Bootable Media

### Linux/macOS

**Using dd (Command Line):**
```bash
# Identify your USB device (be careful!)
lsblk

# Unmount the device
sudo umount /dev/sdX*

# Write ISO to USB (replace sdX with your device)
sudo dd if=free-palestine-os-v1.0-amd64.iso of=/dev/sdX bs=4M status=progress

# Sync to ensure write is complete
sync
```

**Using Etcher (GUI):**
1. Download [Etcher](https://www.balena.io/etcher/)
2. Select ISO file
3. Select USB drive
4. Flash!

### Windows

**Using Rufus:**
1. Download [Rufus](https://rufus.ie)
2. Insert USB drive (8GB minimum)
3. Select ISO file
4. Partition scheme: MBR or GPT (match your system)
5. File system: FAT32
6. Click Start

**Using Ventoy:**
1. Download [Ventoy](https://ventoy.net)
2. Install Ventoy to USB
3. Copy ISO file to USB
4. Boot from USB

## Installation Options

### Live Mode (Try Without Installing)
1. Boot from USB
2. Select "Live (amd64)" from GRUB menu
3. System runs from USB without touching hard drive
4. Changes are lost on reboot (unless persistence is configured)

### Install to Hard Drive
1. Boot from USB
2. Select "Install" from desktop or GRUB menu
3. Follow Debian installer:
   - Language: Select your language
   - Location: Select your timezone
   - Keyboard: Select keyboard layout
   - Network: Configure network (optional)
   - Users: Create user account
   - Disk: Partition your hard drive
   - Software: Select desktop environment
4. Complete installation and reboot

### Dual Boot with Windows
1. Shrink Windows partition in Disk Management
2. Boot from Free Palestine OS USB
3. Select "Install"
4. Choose "Manual" partitioning
5. Create partitions:
   - Root (/) : 30GB+ ext4
   - Swap: Equal to RAM size
   - Home (/home): Remaining space
6. Install GRUB to MBR or EFI partition
7. Complete installation

### Persistence (Live USB with Save)
1. Create bootable USB
2. Create second partition on USB:
   - Label: `persistence`
   - Filesystem: ext4
3. Create file `persistence.conf` with content:
   ```
   / union
   ```
4. Boot with `persistence` kernel parameter

## Post-Installation

### First Boot
1. Login with:
   - Username: `palestine`
   - Password: `freepalestine123`

2. Change passwords:
   ```bash
   passwd          # Change user password
   sudo passwd     # Change root password
   ```

3. Update system:
   ```bash
   sudo apt update
   sudo apt upgrade
   ```

### Installing Additional Tools

**From Kali Repositories:**
```bash
sudo apt install kali-linux-everything
```

**From GitHub:**
Tools are pre-installed in `/opt/security-tools/`

### Network Configuration

**Wi-Fi:**
```bash
nmcli device wifi list
nmcli device wifi connect "SSID" password "password"
```

**VPN:**
```bash
sudo openvpn --config config.ovpn
```

## Troubleshooting

### Boot Issues

**Black Screen:**
- At GRUB, press `e`
- Add `nomodeset` to kernel line
- Press F10

**UEFI Issues:**
- Disable Secure Boot in BIOS
- Enable Legacy/CSM mode if needed
- Use USB 2.0 ports for older systems

**SATA Mode:**
- Set SATA to AHCI (not RAID) in BIOS

### Graphics Issues

**NVIDIA:**
```bash
sudo apt install nvidia-driver
```

**AMD:**
```bash
sudo apt install xserver-xorg-video-amdgpu
```

**Intel:**
```bash
sudo apt install xserver-xorg-video-intel
```

### Package Errors

**Fix broken packages:**
```bash
sudo apt --fix-broken install
sudo dpkg --configure -a
sudo apt update
sudo apt upgrade
```

### Recovery Mode

1. Boot from USB
2. Select "Advanced options"
3. Select "Recovery mode"
4. Choose:
   - fsck: Check filesystems
   - clean: Clean package cache
   - dpkg: Fix broken packages
   - root: Root shell

### Getting Help

**Documentation:**
- Check `/usr/share/doc/`
- Online: https://docs.kali.org

**Community:**
- Kali Linux forums
- Debian documentation
- Security communities

---
**Note**: Always backup your data before installing any operating system.
