# Free Palestine OS v1.0

## The Ultimate Security & Development Operating System

Free Palestine OS is a custom Debian-based Linux distribution designed for cybersecurity professionals, developers, and researchers. It combines the power of Kali Linux tools with a beautiful light theme and over 20,000 security tools from GitHub.

### Default Credentials
- **Username**: `palestine`
- **Password**: `freepalestine123`
- **Root Password**: `root123`

### System Requirements
- **CPU**: x86_64 (AMD64) processor
- **RAM**: 4GB minimum (8GB recommended)
- **Storage**: 20GB for live system, 50GB+ for full installation
- **Graphics**: Any GPU with basic 2D support

### Features

#### Desktop Environment
- **XFCE** with Arc Light theme
- **Papyrus** icon theme
- Optimized for daily use and security work
- Arabic language support included

#### Security Tools (20,000+)
- Kali Linux full toolset
- Metasploit Framework
- Radare2 + Cutter + Rizin
- Ghidra SRE
- Nmap, Masscan, Zmap
- Wireshark, Bettercap
- Aircrack-ng suite
- Burp Suite, OWASP ZAP
- Autopsy, Sleuth Kit
- John, Hashcat
- And 19,000+ more tools...

#### Development Environment
- Python 3.11 + pip + venv
- Node.js + npm + TypeScript
- Go, Rust, Ruby
- Java (OpenJDK 17)
- C/C++ build tools
- VS Code OSS
- Vim, NeoVim, Emacs

#### Languages Supported
- English, Arabic, French, German
- Spanish, Russian, Chinese
- Japanese, Korean, Hindi
- Portuguese, Italian, Turkish

### Installation

#### Creating Bootable USB

**Linux/macOS:**
```bash
sudo dd if=free-palestine-os-v1.0-amd64.iso of=/dev/sdX bs=4M status=progress
sync
```

**Windows:**
Use [Rufus](https://rufus.ie) or [Ventoy](https://ventoy.net)

#### Boot Options

If you encounter boot issues:
1. At GRUB menu, press `e`
2. Add `nomodeset` to kernel line for graphics issues
3. Press F10 to boot

### Building From Source

```bash
# 1. Install dependencies
sudo ./scripts/01-setup-build-env.sh

# 2. Build ISO (takes 3-6 hours)
sudo ./scripts/02-build-iso.sh

# 3. Output: free-palestine-os-v1.0-amd64.iso
```

### Directory Structure
```
free-palestine-os/
├── config/
│   ├── auto/config              # Main build configuration
│   ├── archives/                # Repository configurations
│   ├── hooks/
│   │   ├── normal/              # Chroot hooks (installation)
│   │   └── binary/              # Binary hooks (ISO creation)
│   └── package-lists/           # Package lists
│       ├── core.list.chroot
│       ├── security.list.chroot
│       └── dev.list.chroot
├── scripts/
│   ├── 01-setup-build-env.sh
│   └── 02-build-iso.sh
└── docs/
    ├── INSTALL.md
    └── TROUBLESHOOTING.md
```

### Troubleshooting

#### Black Screen on Boot
- Add `nomodeset` kernel parameter
- Try `nouveau.modeset=0` for NVIDIA
- Try `i915.modeset=0` for Intel

#### Package Installation Errors
- Some packages are installed from GitHub instead of repos
- Check `/opt/security-tools/` for GitHub tools

#### Persistence (Save Data)
1. Create second partition labeled `persistence`
2. Create `persistence.conf` with `/ union`
3. Boot with `persistence` parameter

### Keyboard Shortcuts
- `Super+T`: Terminal
- `Super+F`: File Manager
- `Super+R`: Run dialog
- `Super+L`: Lock screen
- `Ctrl+Alt+T`: Terminal (alternate)

### Legal Notice
This operating system is provided for educational and authorized security testing purposes only. Users are responsible for complying with all applicable laws and regulations.

### Credits
- Based on Debian 12 (Bookworm)
- Security tools from Kali Linux
- Additional tools from GitHub security community
- Theme: Arc + Papyrus

### License
Free Palestine OS is free software. Components retain their original licenses.

---
**Version**: 1.0  
**Release Date**: 2026  
**Codename**: Al-Quds
