# Free Palestine OS - Quick Reference

## Default Login
```
Username: palestine
Password: freepalestine123
Root: root123
```

## Essential Commands

### System Update
```bash
sudo apt update && sudo apt upgrade
```

### Tool Locations
- **APT Tools**: `/usr/bin/`, `/usr/sbin/`
- **GitHub Tools**: `/opt/security-tools/`
- **Wordlists**: `/usr/share/wordlists/`
- **Exploits**: `/opt/security-tools/exploit-db/`

### Quick Access
```bash
# Security tools menu
sudo apt install kali-menu

# Metasploit
msfconsole

# Radare2
r2 -v

# Nmap
nmap -v

# Wireshark
wireshark &
```

## Directory Structure
```
/opt/security-tools/
├── exploit-db/          # Exploit databases
├── web-security/        # Web tools
├── network-security/    # Network tools
├── wireless/            # WiFi tools
├── reverse-engineering/ # RE tools
├── forensics/           # Forensics tools
├── osint/               # OSINT tools
├── privesc/             # Privilege escalation
├── crypto-stego/        # Crypto tools
└── bugbounty/           # Bug bounty tools
```

## Keyboard Shortcuts
| Shortcut | Action |
|----------|--------|
| Super+T | Terminal |
| Super+F | File Manager |
| Super+R | Run Dialog |
| Super+L | Lock Screen |
| Ctrl+Alt+T | Terminal |
| Ctrl+Alt+Del | Logout |
| Alt+F2 | Run Command |
| Alt+Tab | Switch Windows |

## Boot Parameters
Edit at GRUB (press `e`):
- `nomodeset` - Fix black screen
- `persistence` - Enable persistence
- `rootdelay=10` - Slow USB fix
- `toram` - Load to RAM

## Network
```bash
# WiFi
nmcli device wifi list
nmcli device wifi connect "SSID" password "pass"

# Static IP
sudo nano /etc/network/interfaces

# VPN
sudo openvpn config.ovpn
```

## Services
```bash
# Start SSH
sudo systemctl start ssh

# Start Postgresql (for Metasploit)
sudo systemctl start postgresql

# Start Tor
sudo systemctl start tor
```

## Troubleshooting
```bash
# Fix broken packages
sudo apt --fix-broken install

# Check logs
sudo journalctl -xe

# Check disk space
df -h

# Check memory
free -h
```

## Support
- Documentation: `/usr/share/doc/`
- Online: See README.md
