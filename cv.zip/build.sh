#!/bin/bash
set -e

VERSION="1.0"
CODENAME="Al-Quds"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

chmod +x scripts/*.sh 2>/dev/null || true
chmod +x config/auto/config 2>/dev/null || true
chmod +x config/hooks/normal/*.hook.chroot 2>/dev/null || true
chmod +x config/hooks/binary/*.hook.binary 2>/dev/null || true

if [ ! -f "README.md" ]; then
    log_error "Cannot find required files in: $SCRIPT_DIR"
    exit 1
fi

if [ "$EUID" -eq 0 ]; then 
    log_error "Don't run as root directly. Use sudo when prompted."
    exit 1
fi

echo "=========================================="
echo "  Free Palestine OS - Build System"
echo "  Version: $VERSION ($CODENAME)"
echo "=========================================="
echo ""
echo "Working Directory: $SCRIPT_DIR"
echo ""
echo "Select an option:"
echo "  1) Full Build (Setup + Build + Validate)"
echo "  2) Setup Build Environment Only"
echo "  3) Build ISO Only (requires setup)"
echo "  4) Validate Build Configuration"
echo "  5) Cleanup Build Environment"
echo "  6) Quick Build (Skip GitHub tools)"
echo "  7) Exit"
echo ""
read -p "Enter choice [1-7]: " choice

case $choice in
    1)
        bash scripts/03-validate.sh || exit 1
        sudo bash scripts/01-setup-build-env.sh || exit 1
        sudo bash scripts/02-build-iso.sh || exit 1
        log_success "FULL BUILD completed!"
        echo "ISO: free-palestine-os-v${VERSION}-amd64.iso"
        ;;
    2) sudo bash scripts/01-setup-build-env.sh ;;
    3) sudo bash scripts/02-build-iso.sh ;;
    4) bash scripts/03-validate.sh ;;
    5) bash scripts/04-cleanup.sh ;;
    6) export SKIP_GITHUB=1; sudo bash scripts/02-build-iso.sh ;;
    7) log_info "Exiting..."; exit 0 ;;
    *) log_error "Invalid choice"; exit 1 ;;
esac
