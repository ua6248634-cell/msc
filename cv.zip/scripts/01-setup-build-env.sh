#!/bin/bash
set -e
echo "[*] Installing build dependencies..."
apt-get update
apt-get install -y live-build debootstrap squashfs-tools xorriso isolinux syslinux-efi grub-pc-bin grub-efi-amd64-bin mtools dosfstools git build-essential cmake curl wget
echo "[*] Setting up Kali repository key..."
wget -q -O - https://archive.kali.org/archive-key.asc | apt-key add -
echo "[+] Build environment ready"
