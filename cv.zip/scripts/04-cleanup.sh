#!/bin/bash
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && cd .. && pwd)"
cd "$SCRIPT_DIR"
echo "[*] Cleaning up..."
pkill -f "lb build" 2>/dev/null || true
lb clean --purge 2>/dev/null || true
rm -f *.iso live-image-* 2>/dev/null || true
rm -rf cache/* .build/ chroot/ binary/ 2>/dev/null || true
echo "[+] Cleanup complete"
