#!/bin/bash
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && cd .. && pwd)"
cd "$SCRIPT_DIR"
echo "=========================================="
echo "  Free Palestine OS - Build Script"
echo "=========================================="
if [ "$EUID" -ne 0 ]; then 
    echo "[-] Please run as root (use sudo)"
    exit 1
fi
echo "[*] Starting build from: $(pwd)"
rm -f live-image-amd64.hybrid.iso
lb clean --purge 2>/dev/null || true
mkdir -p config/hooks/normal config/hooks/binary config/archives config/package-lists
echo "[*] Making hooks executable..."
chmod +x config/hooks/normal/*.hook.chroot 2>/dev/null || true
chmod +x config/hooks/binary/*.hook.binary 2>/dev/null || true
echo "[*] Running lb config..."
lb config
echo "[*] Phase 1: Bootstrap..."
lb bootstrap || { echo "[-] Bootstrap failed"; exit 1; }
echo "[*] Phase 2: Chroot..."
lb chroot || echo "[!] Chroot warnings..."
echo "[*] Phase 3: Installing packages..."
lb chroot_install || echo "[!] Package warnings..."
echo "[*] Phase 4: Running hooks..."
lb chroot_hooks || echo "[!] Hook warnings..."
echo "[*] Phase 5: Binary preparation..."
lb binary || { echo "[-] Binary failed"; exit 1; }
echo "[*] Phase 6: Generating ISO..."
lb binary_iso || { echo "[-] ISO failed"; exit 1; }
if [ -f "live-image-amd64.hybrid.iso" ]; then
    mv live-image-amd64.hybrid.iso free-palestine-os-v1.0-amd64.iso
    echo ""
    echo "[+] BUILD SUCCESSFUL!"
    echo "=========================================="
    echo "ISO: free-palestine-os-v1.0-amd64.iso"
    echo "Size: $(du -h free-palestine-os-v1.0-amd64.iso | cut -f1)"
    echo ""
    echo "Default Credentials:"
    echo "  Username: palestine"
    echo "  Password: freepalestine123"
    echo "  Root: root123"
else
    echo "[-] Build failed"
    exit 1
fi
