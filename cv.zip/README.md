# Free Palestine OS v1.0

## Security & Development Operating System

### Default Credentials
- **Username**: `palestine`
- **Password**: `freepalestine123`
- **Root**: `root123`

### Quick Start
```bash
unzip free-palestine-os-master.zip
cd free-palestine-os-master
./build.sh
```

### Fixed Package Conflicts
- ✅ **GRUB conflict** → APT pinning prevents Kali from overriding Debian packages
- ✅ **cmake conflict** → Priority set to use Debian versions
- ✅ **radare2** → Installed from GitHub
- ✅ **exploitdb** → Installed from GitHub
- ✅ **xfce4-screensaver** → Replaced with light-locker

### APT Pinning Configuration
The build uses `config/archives/kali.pref.chroot` to:
- Prioritize Debian packages (Pin-Priority: 100)
- Allow Kali tools (Pin-Priority: 500)
- Block Kali's GRUB/cmake (Pin-Priority: 1)

**Al-Quds - FREE PALESTINE** 🇵🇸
