# Installation Guide

## Bootable USB
```bash
sudo dd if=free-palestine-os-v1.0-amd64.iso of=/dev/sdX bs=4M status=progress
```

## Boot Troubleshooting
Add `nomodeset` at GRUB if black screen.
