# Troubleshooting

## Package Conflicts
APT pinning is configured in `config/archives/kali.pref.chroot` to prevent conflicts between Debian and Kali repositories.

## Build Errors
If you see dependency conflicts, the APT pinning should resolve them automatically.
