# Free Palestine OS v1.0

## Security & Development Operating System

### Default Credentials
- **Username**: `palestine`
- **Password**: `freepalestine123`
- **Root**: `root123`

### Quick Start
```bash
unzip free-palestine-os-master.zip
cd free-palestine-os-master
./build.sh
```

### Features
- Light Theme (Arc + Papyrus)
- 20,000+ Security Tools from GitHub
- Kali Linux Repository
- Radare2 + Rizin + Ghidra
- Full Development Environment

### Fixed Errors
- ✅ radare2 → Installed from GitHub
- ✅ exploitdb → Installed from GitHub  
- ✅ xfce4-screensaver → Replaced with light-locker
- ✅ python3-crypto → Replaced with python3-pycryptodome
- ✅ Permission errors → Using 'bash' to run scripts

**Al-Quds - FREE PALESTINE** 🇵🇸
