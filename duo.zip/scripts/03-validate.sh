#!/bin/bash
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && cd .. && pwd)"
cd "$SCRIPT_DIR"
echo "=========================================="
echo "  Free Palestine OS - Validator"
echo "=========================================="
ERRORS=0
check() { 
    if [ -e "$1" ]; then 
        echo "  [OK] $1"; 
    else 
        echo "  [MISSING] $1"; 
        ((ERRORS++)); 
    fi; 
}
echo "Checking files..."
check "config/auto/config"
check "config/package-lists/core.list.chroot"
check "config/package-lists/security.list.chroot"
check "config/package-lists/dev.list.chroot"
check "scripts/01-setup-build-env.sh"
check "scripts/02-build-iso.sh"
check "scripts/03-validate.sh"
check "scripts/04-cleanup.sh"
check "README.md"
if [ $ERRORS -eq 0 ]; then 
    echo "[OK] All files present"; 
else 
    echo "[ERROR] $ERRORS files missing"; 
    exit 1; 
fi
