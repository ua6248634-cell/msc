#!/bin/bash
set -e
echo "[*] Post-installation setup..."
apt-get update && apt-get upgrade -y
apt-get install -y firmware-linux firmware-linux-nonfree firmware-misc-nonfree firmware-realtek firmware-atheros firmware-brcm80211 firmware-iwlwifi
ufw default deny incoming
ufw default allow outgoing
ufw allow ssh
ufw enable 2>/dev/null || true
systemctl enable unattended-upgrades
mkdir -p /home/palestine/{Documents,Downloads,Desktop,Tools}
chown -R palestine:palestine /home/palestine
echo "[+] Post-install complete"
