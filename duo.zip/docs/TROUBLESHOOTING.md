# Troubleshooting

## Permission Denied Errors
All scripts now use `bash script.sh` instead of direct execution.

## Build Errors
Run `./build.sh` and select option 4 to validate first.
